package net.rpgpack.rpg.client.animation;

/**
 * Layers from low to high priority on top of the BASE pose (the neutral animation pose = weapon exactly at its
 * base transform). Evaluation: start from the base, then each playing layer is blended over the result by its
 * weight, so a higher priority layer wins. The result goes into the caller's {@link PoseBuffer}; nothing is
 * allocated.
 */
public final class AnimationStack {
    private final AnimationLayer[] layers;
    private final PoseBuffer scratch = new PoseBuffer();

    public AnimationStack(AnimationLayer... layers) {
        this.layers = layers.clone();
        for (int i = 1; i < this.layers.length; i++) { // tiny insertion sort by priority, once
            AnimationLayer l = this.layers[i];
            int j = i - 1;
            while (j >= 0 && this.layers[j].priority() > l.priority()) {
                this.layers[j + 1] = this.layers[j];
                j--;
            }
            this.layers[j + 1] = l;
        }
    }

    public void tick() {
        for (AnimationLayer layer : layers) {
            layer.tick();
        }
    }

    /** Final pose for this frame. Returns false when every layer is idle (out = neutral base pose). */
    public boolean sample(float tickDelta, PoseBuffer out) {
        out.setIdentity();
        boolean any = false;
        for (AnimationLayer layer : layers) {
            if (layer.sample(tickDelta, scratch)) {
                out.lerp(out, scratch, layer.weight());
                any = true;
            }
        }
        return any;
    }
}
