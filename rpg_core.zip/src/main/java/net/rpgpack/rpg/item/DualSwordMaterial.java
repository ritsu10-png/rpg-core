package net.rpgpack.rpg.item;

import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;

/**
 * Material of a Dual Sword. Common (server-safe) code: only holds names/ids.
 * The texture prefix follows the supplied file names (e.g. "wooden", "golden").
 */
public enum DualSwordMaterial {
    WOOD("dual_sword_wood", "wooden"),
    STONE("dual_sword_stone", "stone"),
    COPPER("dual_sword_copper", "copper"),
    IRON("dual_sword_iron", "iron"),
    GOLD("dual_sword_gold", "golden"),
    DIAMOND("dual_sword_diamond", "diamond"),
    NETHERITE("dual_sword_netherite", "netherite");

    private final String itemName;
    private final String texturePrefix;

    DualSwordMaterial(String itemName, String texturePrefix) {
        this.itemName = itemName;
        this.texturePrefix = texturePrefix;
    }

    public String itemName() {
        return itemName;
    }

    /** Full crossed (X) icon texture - inventory only: rpg:item/<prefix>_dual_sword */
    public Identifier iconModelTexture() {
        return new Identifier(Rpg.MOD_ID, "item/" + texturePrefix + "_dual_sword");
    }

    /** Single sword texture for the LEFT hand: rpg:textures/item/<prefix>_dual_sword_left.png */
    public Identifier leftHandTexture() {
        return new Identifier(Rpg.MOD_ID, "textures/item/" + texturePrefix + "_dual_sword_left.png");
    }

    /** Single sword texture for the RIGHT hand: rpg:textures/item/<prefix>_dual_sword_right.png */
    public Identifier rightHandTexture() {
        return new Identifier(Rpg.MOD_ID, "textures/item/" + texturePrefix + "_dual_sword_right.png");
    }
}
