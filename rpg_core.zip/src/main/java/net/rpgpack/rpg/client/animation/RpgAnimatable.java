package net.rpgpack.rpg.client.animation;

/**
 * Implemented onto AbstractClientPlayerEntity by a mixin: gives the trigger and the renderer direct access to the
 * player's animation state (a plain field read, no map lookup). Cast a client player to this interface.
 */
public interface RpgAnimatable {
    PlayerAnimationState rpg$getAnimationState();
}
