package net.rpgpack.rpg.client.animation;

import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Turns BASE pose + ANIMATION pose into the final transform on the matrix stack, fresh every call:
 *
 *   final = T(animPos) * T(grip) * R(animRot) * T(-grip) * [ T(basePos) * R(baseRot) * S(baseScale) ] * T(grip) * S(animScale) * T(-grip)
 *
 * where {@code grip} is the pivot point in the HAND space (the point of the weapon that stays in the hand).
 * The weapon is therefore rotated and scaled around its grip, never around the middle of the blade, and nothing
 * is ever accumulated: the base pose is read-only and the animation pose is a delta evaluated for this frame only.
 *
 * Hand space = the space after the vanilla hand transform. With the arm hanging down: +X = player's right,
 * +Y = forward, +Z = up along the arm (toward the shoulder). Animation positions use it (1/16 block),
 * animation rotations turn around the grip about these axes (degrees, X then Y then Z).
 *
 * Render-thread only: the scratch objects below are reused (MatrixStack copies what it needs).
 */
public final class PoseApplier {
    private static final float DEG = (float) (Math.PI / 180.0);
    private static final Quaternionf BASE_ROT = new Quaternionf();
    private static final Quaternionf ANIM_ROT = new Quaternionf();
    private static final Vector3f PIVOT = new Vector3f();

    private PoseApplier() {
    }

    /** Base pose only (no animation). */
    public static void applyBase(MatrixStack matrices, Pose base) {
        matrices.translate(base.posX() / 16f, base.posY() / 16f, base.posZ() / 16f);
        matrices.multiply(BASE_ROT.rotationXYZ(base.rotX() * DEG, base.rotY() * DEG, base.rotZ() * DEG));
        matrices.scale(base.scaleX(), base.scaleY(), base.scaleZ());
    }

    /**
     * Base + animation. {@code gripX/Y/Z} is the grip in the weapon's own mesh space, measured from the mesh
     * centre, in blocks (before the base scale).
     */
    public static void apply(MatrixStack matrices, Pose base, PoseBuffer anim, float gripX, float gripY, float gripZ) {
        BASE_ROT.rotationXYZ(base.rotX() * DEG, base.rotY() * DEG, base.rotZ() * DEG);
        // where the grip is in hand space with the base pose alone
        PIVOT.set(gripX * base.scaleX(), gripY * base.scaleY(), gripZ * base.scaleZ());
        BASE_ROT.transform(PIVOT);
        float cx = base.posX() / 16f + PIVOT.x;
        float cy = base.posY() / 16f + PIVOT.y;
        float cz = base.posZ() / 16f + PIVOT.z;

        matrices.translate(anim.get(Pose.POS_X) / 16f, anim.get(Pose.POS_Y) / 16f, anim.get(Pose.POS_Z) / 16f);
        matrices.translate(cx, cy, cz);
        matrices.multiply(ANIM_ROT.rotationXYZ(anim.get(Pose.ROT_X) * DEG, anim.get(Pose.ROT_Y) * DEG,
                anim.get(Pose.ROT_Z) * DEG));
        matrices.translate(-cx, -cy, -cz);

        applyBase(matrices, base);

        matrices.translate(gripX, gripY, gripZ);
        matrices.scale(anim.get(Pose.SCALE_X), anim.get(Pose.SCALE_Y), anim.get(Pose.SCALE_Z));
        matrices.translate(-gripX, -gripY, -gripZ);
    }
}
