package net.rpgpack.rpg.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.rpgpack.rpg.client.animation.PlayerAnimationState;
import net.rpgpack.rpg.client.animation.RpgAnimatable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Gives every CLIENT player (local and remote) its own animation state, living and dying with the entity.
 * The class is client-only, so the server never sees this.
 */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin implements RpgAnimatable {
    @Unique
    private PlayerAnimationState rpg$animationState = new PlayerAnimationState();

    @Override
    public PlayerAnimationState rpg$getAnimationState() {
        return rpg$animationState;
    }
}
