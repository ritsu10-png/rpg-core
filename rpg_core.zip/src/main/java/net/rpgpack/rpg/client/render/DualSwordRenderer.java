package net.rpgpack.rpg.client.render;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.ModelWithArms;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import net.rpgpack.rpg.item.DualSwordItem;
import net.rpgpack.rpg.item.DualSwordMaterial;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Renders the custom Dual Sword mesh. PlayerAnimator is responsible for posing the
 * player arms; this class only attaches the sword mesh to the already-posed hand.
 */
public final class DualSwordRenderer {
    private DualSwordRenderer() {}

    public static DualSwordItem getMainHandDualSword(LivingEntity entity) {
        ItemStack stack = entity.getMainHandStack();
        return stack.getItem() instanceof DualSwordItem item ? item : null;
    }

    public static void renderFirstPerson(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                         DualSwordMaterial material, Arm arm) {
        matrices.push();
        DualSwordTransforms.applyFirstPerson(matrices, arm);
        emitMesh(matrices, vcp, light, material, arm);
        matrices.pop();
    }

    public static void renderThirdPerson(LivingEntity entity, ModelWithArms model, MatrixStack matrices,
                                         VertexConsumerProvider vcp, int light, DualSwordMaterial material,
                                         Arm mainArm, boolean both) {
        renderThirdPersonArm(model, matrices, vcp, light, material, mainArm);
        if (both) {
            renderThirdPersonArm(model, matrices, vcp, light, material, mainArm.getOpposite());
        }
    }

    private static void renderThirdPersonArm(ModelWithArms model, MatrixStack matrices, VertexConsumerProvider vcp,
                                              int light, DualSwordMaterial material, Arm arm) {
        matrices.push();
        model.setArmAngle(arm, matrices);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f));
        matrices.translate((arm == Arm.LEFT ? -1 : 1) / 16.0f, 0.125f, -0.625f);
        DualSwordTransforms.applyThirdPerson(matrices, arm);
        emitMesh(matrices, vcp, light, material, arm);
        matrices.pop();
    }

    private static void emitMesh(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                  DualSwordMaterial material, Arm arm) {
        Identifier texture = arm == Arm.RIGHT ? material.rightHandTexture() : material.leftHandTexture();
        DualSwordMeshes.Mesh mesh = DualSwordMeshes.get(texture);

        matrices.push();
        matrices.translate(-0.5f, -0.5f, -0.5f);
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nrm = entry.getNormalMatrix();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));

        float[] d = mesh.data();
        int stride = DualSwordMeshes.FLOATS_PER_VERTEX;
        int vertexCount = mesh.quadCount() * 4;
        for (int i = 0; i < vertexCount; i++) {
            int o = i * stride;
            vc.vertex(pos, d[o], d[o + 1], d[o + 2])
                    .color(255, 255, 255, 255)
                    .texture(d[o + 3], d[o + 4])
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(nrm, d[o + 5], d[o + 6], d[o + 7])
                    .next();
        }
        matrices.pop();
    }
}
