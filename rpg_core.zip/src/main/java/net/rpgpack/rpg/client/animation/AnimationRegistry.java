package net.rpgpack.rpg.client.animation;

import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/**
 * All clips by id. Filled once at client start-up; looked up when an attack starts (never per render frame).
 */
public final class AnimationRegistry {
    private static final Map<Identifier, Animation> ANIMATIONS = new HashMap<>();

    private AnimationRegistry() {
    }

    public static void register(Identifier id, Animation animation) {
        if (ANIMATIONS.putIfAbsent(id, animation) != null) {
            throw new IllegalStateException("Animation already registered: " + id);
        }
    }

    /** The clip, or null when the id is unknown. */
    public static Animation get(Identifier id) {
        return ANIMATIONS.get(id);
    }
}
