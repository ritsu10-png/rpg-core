package net.rpgpack.rpg.client.animation.dualsword;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.rpgpack.rpg.client.animation.Animation;
import net.rpgpack.rpg.client.animation.AnimationRegistry;
import net.rpgpack.rpg.client.animation.PlayerAnimationState;
import net.rpgpack.rpg.client.animation.RpgAnimatable;
import net.rpgpack.rpg.item.DualSwordItem;

/**
 * Explicit attack trigger of the Dual Sword. Called by LivingEntityMixin the moment a client player's swing
 * (re)starts - a click that misses and a click that hits both swing, so both land here; nothing depends on
 * hit confirmation, the target or a hitbox.
 *
 * Decides only which sword attacks and starts that clip on the player's AnimationState:
 *  - off hand empty (both swords shown): RIGHT, LEFT, RIGHT, LEFT ... starting with the main arm; an off-hand
 *    swing forces the off-hand arm and the chain continues from there; the chain starts over on the main arm
 *    after COMBO_RESET_TICKS without an attack.
 *  - off hand busy (only the main sword is shown): always the main arm.
 */
public final class DualSwordAttackTrigger {
    private static final int COMBO_RESET_TICKS = 24;
    private static final float FADE_TICKS = 2f;
    private static final float SPEED = 1f;

    private DualSwordAttackTrigger() {
    }

    public static void onSwing(AbstractClientPlayerEntity player, Hand hand) {
        if (!(player.getMainHandStack().getItem() instanceof DualSwordItem)) {
            return; // not a Dual Sword in the main hand: vanilla only
        }
        PlayerAnimationState state = ((RpgAnimatable) player).rpg$getAnimationState();
        int age = player.age;
        Arm last = state.lastAttackArm();
        if (last != null && state.lastAttackAge() == age) {
            return; // second swingHand call in the same tick
        }

        Arm main = player.getMainArm();
        boolean both = player.getOffHandStack().isEmpty();
        Arm arm;
        if (!both) {
            arm = main;
        } else if (hand == Hand.OFF_HAND) {
            arm = main.getOpposite();
        } else if (last == null || age - state.lastAttackAge() > COMBO_RESET_TICKS) {
            arm = main;
        } else {
            arm = last.getOpposite();
        }

        Animation clip = AnimationRegistry.get(arm == Arm.RIGHT
                ? DualSwordAnimations.ATTACK_RIGHT_ID : DualSwordAnimations.ATTACK_LEFT_ID);
        if (clip != null) {
            state.playAttack(arm, clip, SPEED, FADE_TICKS, age);
        }
    }
}
