package net.rpgpack.rpg.client.animation.dualsword;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.rpgpack.rpg.client.animation.AnimationState;
import net.rpgpack.rpg.client.animation.PoseBuffer;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Per-player controller of the Dual Sword clips. States:
 *   IDLE          no clip playing on that arm (neutral pose, the base pose is rendered untouched)
 *   ATTACK_RIGHT  DualSwordAnimations.ATTACK_RIGHT on the right arm's sword
 *   ATTACK_LEFT   DualSwordAnimations.ATTACK_LEFT on the left arm's sword
 * Each arm has its own playback slot, so the sword that is not attacking stays at rest and a finishing swing
 * can run out while the other arm starts. Players only (mobs never get a controller).
 *
 * Trigger: a NEW vanilla swing (handSwinging turns on, or handSwingTicks restarts from a lower value).
 * Which sword attacks:
 *  - off hand empty (both swords shown): RIGHT, LEFT, RIGHT, LEFT ... alternating, starting with the main arm;
 *    an off-hand swing (preferredHand == OFF_HAND) forces the off-hand arm and the chain continues from there;
 *    the chain starts over on the main arm after COMBO_RESET_TICKS without an attack.
 *  - off hand busy (only the main sword is shown): always the main arm.
 * A vanilla swing can only restart in the second half of the previous one, so the previous clip is already past
 * its strike when the next one begins; it finishes its follow-through while the other sword winds up.
 * Restarting the SAME arm cross-fades from its current pose (no snap).
 *
 * Render thread only. Adding a state (sprint, ...) later = one more clip in DualSwordAnimations and one more
 * trigger here; the clip playback itself lives in the generic animation package.
 */
public final class DualSwordAnimationController {
    /** No attack for this long (ticks) = the next one starts again on the main arm. */
    private static final float COMBO_RESET_TICKS = 24f;
    /** Cross-fade length when a clip replaces one that is still playing. */
    private static final float BLEND_TICKS = 2f;
    /** Not rendered for this long (ticks): forget everything, never trigger from old swing data. */
    private static final float STALE_TICKS = 6f;

    private static final Map<Entity, DualSwordAnimationController> CONTROLLERS = new WeakHashMap<>();

    private final AnimationState right = new AnimationState();
    private final AnimationState left = new AnimationState();
    private float lastNow = Float.NaN;
    private boolean lastSwinging;
    private int lastSwingTicks;
    private Arm lastAttackArm;
    private float lastAttackStart;

    private DualSwordAnimationController() {
    }

    /**
     * Brings the player's controller up to date for this render frame and returns it. Safe to call once per
     * sword in the same frame: the second call changes nothing.
     *
     * @param both true when the off-hand sword is shown (off hand empty)
     */
    public static DualSwordAnimationController update(PlayerEntity player, float tickDelta, boolean both) {
        DualSwordAnimationController c = CONTROLLERS.get(player);
        if (c == null) {
            c = new DualSwordAnimationController();
            CONTROLLERS.put(player, c);
        }
        c.advance(player, player.age + tickDelta, both);
        return c;
    }

    /** Writes the arm's animation pose (delta from base) into {@code out}; false = idle (out is neutral). */
    public boolean sample(Arm arm, PoseBuffer out) {
        return (arm == Arm.RIGHT ? right : left).sample(lastNow, out);
    }

    private void advance(PlayerEntity player, float now, boolean both) {
        if (now == lastNow) {
            return;
        }
        boolean swinging = player.handSwinging;
        int swingTicks = player.handSwingTicks;

        boolean fresh = Float.isNaN(lastNow) || now < lastNow - 1f || now - lastNow > STALE_TICKS;
        if (fresh) {
            right.stop();
            left.stop();
            lastAttackArm = null;
        } else if (swinging && (!lastSwinging || swingTicks < lastSwingTicks)) {
            startAttack(player, now, both);
        }
        lastSwinging = swinging;
        lastSwingTicks = swingTicks;
        lastNow = now;
    }

    private void startAttack(PlayerEntity player, float now, boolean both) {
        Arm main = player.getMainArm();
        Arm arm;
        if (!both) {
            arm = main;
        } else if (player.preferredHand == Hand.OFF_HAND) {
            arm = main.getOpposite();
        } else if (lastAttackArm == null || now - lastAttackStart > COMBO_RESET_TICKS) {
            arm = main;
        } else {
            arm = lastAttackArm.getOpposite();
        }

        if (arm == Arm.RIGHT) {
            right.play(DualSwordAnimations.ATTACK_RIGHT, now, BLEND_TICKS);
        } else {
            left.play(DualSwordAnimations.ATTACK_LEFT, now, BLEND_TICKS);
        }
        lastAttackArm = arm;
        lastAttackStart = now;
    }
}
