package net.rpgpack.rpg.client.render;

import net.minecraft.util.Arm;
import net.rpgpack.rpg.client.animation.Pose;

/**
 * SINGLE place that holds every tunable BASE value for the Dual Sword hand rendering (animation clips live in
 * DualSwordAnimations; they are deltas on top of these poses).
 *
 * Pose fields:
 *   position   translation in 1/16 block units (same units as item "display" JSON)
 *   rotation   degrees (applied X, then Y, then Z - same as vanilla item display transforms)
 *   scale      per axis (uniform here)
 *
 * The initial values start from vanilla's "item/handheld" display transforms, which already put a sword sprite
 * naturally in each hand. Tweak them here - nothing else needs to change.
 */
public final class DualSwordTransforms {
    private DualSwordTransforms() {
    }

    // ---------------------------------------------------------------- first person
    public static Pose FIRST_PERSON_RIGHT = Pose.of(1.13f, 3.2f, 1.13f, 0f, -90f, 25f, 0.68f);
    public static Pose FIRST_PERSON_LEFT = Pose.of(-1.13f, 3.2f, 1.13f, 0f, -90f, 25f, 0.68f);

    // ---------------------------------------------------------------- third person
    public static Pose THIRD_PERSON_RIGHT = Pose.of(0f, 4f, 0.5f, 0f, -90f, 55f, 0.85f);
    public static Pose THIRD_PERSON_LEFT = Pose.of(0f, 4f, 0.5f, 0f, -90f, 55f, 0.85f);

    // ---------------------------------------------------------------- grip (animation pivot)
    /**
     * Where the hand holds the sword, in the sword mesh's own space measured from the mesh centre, in blocks
     * (before the pose scale). The 32x32 hand sprites have the handle in the lower-left corner, around pixel
     * (5, 26), i.e. (5/32 - 0.5, 1 - 26/32 - 0.5). Animations rotate and scale the sword around this point.
     */
    public static float GRIP_X = -0.34f;
    public static float GRIP_Y = -0.31f;
    public static float GRIP_Z = 0f;

    // ---------------------------------------------------------------- behaviour flags (first person)
    /** The off-hand sword plays the same swing as the main hand when attacking. */
    public static boolean OFFHAND_FOLLOWS_MAIN_SWING = true;
    /** The off-hand sword plays the same equip (raise) animation as the main hand. */
    public static boolean OFFHAND_FOLLOWS_MAIN_EQUIP = true;

    public static Pose firstPerson(Arm arm) {
        return arm == Arm.RIGHT ? FIRST_PERSON_RIGHT : FIRST_PERSON_LEFT;
    }

    public static Pose thirdPerson(Arm arm) {
        return arm == Arm.RIGHT ? THIRD_PERSON_RIGHT : THIRD_PERSON_LEFT;
    }
}
