package net.rpgpack.rpg.client.render;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.ModelWithArms;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.rpgpack.rpg.item.DualSwordItem;
import net.rpgpack.rpg.item.DualSwordMaterial;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Draws the two single-sword hand textures for ONE held Dual Sword item.
 * Called only from the mixins, and only when the main hand holds a DualSwordItem.
 * All numbers live in {@link DualSwordTransforms}.
 */
public final class DualSwordRenderer {
    private static final float DEG = (float) (Math.PI / 180.0);

    private DualSwordRenderer() {
    }

    /** Returns the Dual Sword item in the entity's main hand, or null (vanilla rendering must be kept). */
    public static DualSwordItem getMainHandDualSword(LivingEntity entity) {
        ItemStack stack = entity.getMainHandStack();
        return stack.getItem() instanceof DualSwordItem item ? item : null;
    }

    /**
     * First person: matrices must already contain the vanilla hand/equip/swing transforms for this arm.
     * {@code player} is only used to look up the sprint state (null = always idle pose).
     */
    public static void renderFirstPerson(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                         DualSwordMaterial material, Arm arm, float swingProgress,
                                         PlayerEntity player, float tickDelta) {
        matrices.push();
        DualSwordTransforms.SwingOffset so = DualSwordTransforms.swingOffset(arm);
        float s = MathHelper.sin(swingProgress * (float) Math.PI);
        matrices.translate(so.x() / 16f * s, so.y() / 16f * s, so.z() / 16f * s);

        DualSwordAnimation.Sprint sprint = player == null ? null : DualSwordAnimation.sprint(player, tickDelta);
        DualSwordTransforms.Pose pose = sprint == null
                ? DualSwordTransforms.firstPerson(arm)
                : DualSwordAnimation.firstPersonPose(arm, sprint);
        renderSword(matrices, vcp, light, material, arm, pose);
        matrices.pop();
    }

    /**
     * Third person: the main-hand arm always gets its sword, the other arm gets the second sword
     * only when {@code both} is true (off hand empty).
     * The sprint pose is applied only when {@code entity} is a sprinting PLAYER; every other entity
     * (mobs, armor stands, ...) keeps the unchanged idle rendering.
     */
    public static void renderThirdPerson(LivingEntity entity, ModelWithArms model, MatrixStack matrices,
                                         VertexConsumerProvider vcp, int light, DualSwordMaterial material,
                                         Arm mainArm, boolean both) {
        DualSwordAnimation.Sprint sprint = null;
        if (entity instanceof PlayerEntity player) {
            sprint = DualSwordAnimation.sprint(player, MinecraftClient.getInstance().getTickDelta());
        }
        renderThirdPersonArm(model, matrices, vcp, light, material, mainArm, sprint);
        if (both) {
            renderThirdPersonArm(model, matrices, vcp, light, material, mainArm.getOpposite(), sprint);
        }
    }

    private static void renderThirdPersonArm(ModelWithArms model, MatrixStack matrices, VertexConsumerProvider vcp,
                                             int light, DualSwordMaterial material, Arm arm,
                                             DualSwordAnimation.Sprint sprint) {
        DualSwordTransforms.Pose pose = DualSwordTransforms.thirdPerson(arm);

        if (sprint != null) {
            if (arm == Arm.LEFT) {
                // left sword: travels hand <-> back (ENTER / SPRINT / EXIT all go through the same blend)
                if (model instanceof BipedEntityModel<?> biped) {
                    renderLeftHandToBack(model, biped, matrices, vcp, light, material, sprint);
                    return;
                }
            } else {
                // right sword: stays in the hand, held low
                pose = DualSwordAnimation.thirdPersonHandPose(arm, sprint);
            }
        }

        matrices.push();
        applyHandChain(model, matrices, arm);
        renderSword(matrices, vcp, light, material, arm, pose);
        matrices.pop();
    }

    /** Identical to vanilla HeldItemFeatureRenderer#renderItem up to the item itself. */
    private static void applyHandChain(ModelWithArms model, MatrixStack matrices, Arm arm) {
        model.setArmAngle(arm, matrices);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f));
        matrices.translate((arm == Arm.LEFT ? -1 : 1) / 16.0f, 0.125f, -0.625f);
    }

    /**
     * Draws the LEFT sword (third person, sprinting player) somewhere between its idle hand transform and its
     * back transform. The back transform is relative to the torso (so it follows body lean/crouch): the body
     * part's own transform is applied first, then the flip vanilla's entity renderer uses, so the pose frame is
     * upright and seen from behind (see DualSwordTransforms.BACK_SWORD). The blend weight comes from the
     * animation state, so ENTER and EXIT travel smoothly and SPRINT sits exactly on the back.
     */
    private static void renderLeftHandToBack(ModelWithArms model, BipedEntityModel<?> biped, MatrixStack matrices,
                                             VertexConsumerProvider vcp, int light, DualSwordMaterial material,
                                             DualSwordAnimation.Sprint sprint) {
        Matrix4f base = new Matrix4f(matrices.peek().getPositionMatrix());

        matrices.push();
        applyHandChain(model, matrices, Arm.LEFT);
        applyPose(matrices, DualSwordTransforms.thirdPerson(Arm.LEFT));
        Matrix4f hand = new Matrix4f(matrices.peek().getPositionMatrix());
        matrices.pop();

        matrices.push();
        biped.body.rotate(matrices);
        matrices.scale(-1.0f, -1.0f, 1.0f);
        applyPose(matrices, DualSwordAnimation.backPose(sprint));
        Matrix4f back = new Matrix4f(matrices.peek().getPositionMatrix());
        matrices.pop();

        Matrix4f blended = DualSwordAnimation.blendHandToBack(base, hand, back, sprint.blend());

        matrices.push();
        MatrixStack.Entry entry = matrices.peek();
        entry.getPositionMatrix().set(blended);
        entry.getNormalMatrix().set(new Matrix3f().rotation(blended.getUnnormalizedRotation(new Quaternionf())));
        emitMesh(matrices, vcp, light, material, Arm.LEFT);
        matrices.pop();
    }

    /** translate / rotate / scale of a pose (the sword's centre ends up at the origin of the stack). */
    private static void applyPose(MatrixStack matrices, DualSwordTransforms.Pose pose) {
        matrices.translate(pose.x() / 16f, pose.y() / 16f, pose.z() / 16f);
        matrices.multiply(new Quaternionf().rotationXYZ(pose.rotX() * DEG, pose.rotY() * DEG, pose.rotZ() * DEG));
        matrices.scale(pose.scale(), pose.scale(), pose.scale());
    }

    private static void renderSword(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                    DualSwordMaterial material, Arm arm, DualSwordTransforms.Pose pose) {
        matrices.push();
        applyPose(matrices, pose);
        emitMesh(matrices, vcp, light, material, arm);
        matrices.pop();
    }

    /** Emits the sword mesh around the current origin (mesh space 0..1 -> centred). */
    private static void emitMesh(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                 DualSwordMaterial material, Arm arm) {
        Identifier texture = arm == Arm.RIGHT ? material.rightHandTexture() : material.leftHandTexture();
        DualSwordMeshes.Mesh mesh = DualSwordMeshes.get(texture);

        matrices.push();
        matrices.translate(-0.5f, -0.5f, -0.5f);

        MatrixStack.Entry entry = matrices.peek();
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nrm = entry.getNormalMatrix();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));

        float[] d = mesh.data();
        int stride = DualSwordMeshes.FLOATS_PER_VERTEX;
        int vertexCount = mesh.quadCount() * 4;
        for (int i = 0; i < vertexCount; i++) {
            int o = i * stride;
            vc.vertex(pos, d[o], d[o + 1], d[o + 2])
                    .color(255, 255, 255, 255)
                    .texture(d[o + 3], d[o + 4])
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(nrm, d[o + 5], d[o + 6], d[o + 7])
                    .next();
        }
        matrices.pop();
    }
}
