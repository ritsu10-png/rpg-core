package net.rpgpack.rpg.client.animation;

/**
 * Reusable, mutable output of an evaluation. One buffer is filled again every frame, so evaluating an animation
 * allocates nothing. It is only ever an OUTPUT: it is overwritten completely each time, never added to.
 */
public final class PoseBuffer {
    private final float[] v = new float[Pose.CHANNELS];

    public PoseBuffer() {
        setIdentity();
    }

    public void setIdentity() {
        set(Pose.IDENTITY);
    }

    public void set(Pose pose) {
        for (int i = 0; i < Pose.CHANNELS; i++) {
            v[i] = pose.channel(i);
        }
    }

    public void set(int channel, float value) {
        v[channel] = value;
    }

    public float get(int channel) {
        return v[channel];
    }

    /** this = a + (b - a) * t, channel by channel. {@code a} / {@code b} may be this buffer. */
    public void lerp(PoseBuffer a, PoseBuffer b, float t) {
        for (int i = 0; i < Pose.CHANNELS; i++) {
            v[i] = a.v[i] + (b.v[i] - a.v[i]) * t;
        }
    }
}
