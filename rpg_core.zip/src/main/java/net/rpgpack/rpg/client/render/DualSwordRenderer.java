package net.rpgpack.rpg.client.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.ModelWithArms;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import net.rpgpack.rpg.client.animation.Pose;
import net.rpgpack.rpg.client.animation.PoseApplier;
import net.rpgpack.rpg.client.animation.PoseBuffer;
import net.rpgpack.rpg.client.animation.dualsword.DualSwordAnimationController;
import net.rpgpack.rpg.item.DualSwordItem;
import net.rpgpack.rpg.item.DualSwordMaterial;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Draws the two single-sword hand textures for ONE held Dual Sword item.
 * Called only from the mixins, and only when the main hand holds a DualSwordItem.
 * Base numbers live in {@link DualSwordTransforms}; animation poses come from the animation controller.
 *
 * Third-person pipeline per sword:
 *   vanilla arm pose -> hand transform -> [animation pose around the grip] -> base pose -> mesh
 * (see PoseApplier for the exact composition).
 */
public final class DualSwordRenderer {
    /** Animation pose of the sword being drawn (render thread only; refilled completely before every use). */
    private static final PoseBuffer ANIM = new PoseBuffer();

    private DualSwordRenderer() {
    }

    /** Returns the Dual Sword item in the entity's main hand, or null (vanilla rendering must be kept). */
    public static DualSwordItem getMainHandDualSword(LivingEntity entity) {
        ItemStack stack = entity.getMainHandStack();
        return stack.getItem() instanceof DualSwordItem item ? item : null;
    }

    /**
     * First person: matrices must already contain the vanilla hand/equip/swing transforms for this arm.
     * Idle base pose only (first-person animation comes later).
     */
    public static void renderFirstPerson(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                         DualSwordMaterial material, Arm arm) {
        matrices.push();
        PoseApplier.applyBase(matrices, DualSwordTransforms.firstPerson(arm));
        emitMesh(matrices, vcp, light, material, arm);
        matrices.pop();
    }

    /**
     * Third person: the main-hand arm always gets its sword, the other arm gets the second sword
     * only when {@code both} is true (off hand empty). Every sword is drawn from its own arm's hand
     * transform, so it follows that arm (idle, walking, swinging) and never leaves the hand.
     * Animation applies to PLAYERS only; every other entity keeps the plain base pose.
     */
    public static void renderThirdPerson(LivingEntity entity, ModelWithArms model, MatrixStack matrices,
                                         VertexConsumerProvider vcp, int light, DualSwordMaterial material,
                                         Arm mainArm, boolean both) {
        DualSwordAnimationController controller = null;
        if (entity instanceof PlayerEntity player) {
            controller = DualSwordAnimationController.update(player, MinecraftClient.getInstance().getTickDelta(), both);
        }
        renderThirdPersonArm(model, matrices, vcp, light, material, mainArm, controller);
        if (both) {
            renderThirdPersonArm(model, matrices, vcp, light, material, mainArm.getOpposite(), controller);
        }
    }

    private static void renderThirdPersonArm(ModelWithArms model, MatrixStack matrices, VertexConsumerProvider vcp,
                                             int light, DualSwordMaterial material, Arm arm,
                                             DualSwordAnimationController controller) {
        Pose base = DualSwordTransforms.thirdPerson(arm);

        matrices.push();
        applyHandChain(model, matrices, arm);
        if (controller != null && controller.sample(arm, ANIM)) {
            PoseApplier.apply(matrices, base, ANIM, DualSwordTransforms.GRIP_X, DualSwordTransforms.GRIP_Y,
                    DualSwordTransforms.GRIP_Z);
        } else {
            PoseApplier.applyBase(matrices, base);
        }
        emitMesh(matrices, vcp, light, material, arm);
        matrices.pop();
    }

    /** Identical to vanilla HeldItemFeatureRenderer#renderItem up to the item itself. */
    private static void applyHandChain(ModelWithArms model, MatrixStack matrices, Arm arm) {
        model.setArmAngle(arm, matrices);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f));
        matrices.translate((arm == Arm.LEFT ? -1 : 1) / 16.0f, 0.125f, -0.625f);
    }

    /** Emits the sword mesh around the current origin (mesh space 0..1 -> centred). */
    private static void emitMesh(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                 DualSwordMaterial material, Arm arm) {
        Identifier texture = arm == Arm.RIGHT ? material.rightHandTexture() : material.leftHandTexture();
        DualSwordMeshes.Mesh mesh = DualSwordMeshes.get(texture);

        matrices.push();
        matrices.translate(-0.5f, -0.5f, -0.5f);

        MatrixStack.Entry entry = matrices.peek();
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nrm = entry.getNormalMatrix();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));

        float[] d = mesh.data();
        int stride = DualSwordMeshes.FLOATS_PER_VERTEX;
        int vertexCount = mesh.quadCount() * 4;
        for (int i = 0; i < vertexCount; i++) {
            int o = i * stride;
            vc.vertex(pos, d[o], d[o + 1], d[o + 2])
                    .color(255, 255, 255, 255)
                    .texture(d[o + 3], d[o + 4])
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(nrm, d[o + 5], d[o + 6], d[o + 7])
                    .next();
        }
        matrices.pop();
    }
}
