package net.rpgpack.rpg.item;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.rpgpack.rpg.Rpg;

public final class ModItems {
    public static final Item DUAL_SWORD_WOOD = registerDualSword("dual_sword_wood");
    public static final Item DUAL_SWORD_STONE = registerDualSword("dual_sword_stone");
    public static final Item DUAL_SWORD_IRON = registerDualSword("dual_sword_iron");
    public static final Item DUAL_SWORD_GOLD = registerDualSword("dual_sword_gold");
    public static final Item DUAL_SWORD_DIAMOND = registerDualSword("dual_sword_diamond");
    public static final Item DUAL_SWORD_NETHERITE = registerDualSword("dual_sword_netherite");

    private ModItems() {
    }

    private static Item registerDualSword(String name) {
        // Plain item for now: no behavior, attributes, or recipes yet.
        return Registry.register(Registries.ITEM, Rpg.id(name), new Item(new Item.Settings().maxCount(1)));
    }

    /** Called from the mod entrypoint; touching this class runs the static registrations above. */
    public static void register() {
        Rpg.LOGGER.info("Registered Dual Sword items");
    }
}
