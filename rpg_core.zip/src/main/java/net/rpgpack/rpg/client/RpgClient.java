package net.rpgpack.rpg.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;
import net.rpgpack.rpg.client.render.DualSwordMeshes;

public class RpgClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Hand meshes are generated from the hand textures; rebuild them after every resource reload.
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(
                new SimpleSynchronousResourceReloadListener() {
                    @Override
                    public Identifier getFabricId() {
                        return new Identifier(Rpg.MOD_ID, "dual_sword_meshes");
                    }

                    @Override
                    public void reload(ResourceManager manager) {
                        DualSwordMeshes.clear();
                    }
                });
    }
}
