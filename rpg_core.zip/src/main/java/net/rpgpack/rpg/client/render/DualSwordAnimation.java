package net.rpgpack.rpg.client.render;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.rpgpack.rpg.client.render.DualSwordTransforms.Pose;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Client-side animation STATE + CURVES for the Dual Sword (PLAYER only). All tunable numbers live in
 * {@link DualSwordTransforms}; this class turns "what is the player doing and for how long" into a weight
 * and into poses.
 *
 * States:  IDLE -> SPRINT_ENTER -> SPRINT -> SPRINT_EXIT -> IDLE
 *  - IDLE          no state is stored; the renderer uses the existing idle poses untouched.
 *  - SPRINT_ENTER  swords travel from the idle stance into the sprint stance (short wind-up, snappy move,
 *                  tiny overshoot). Interrupted by a stop, it turns into SPRINT_EXIT from the CURRENT weight.
 *  - SPRINT        held while sprinting, with a subtle run bob / sway.
 *  - SPRINT_EXIT   swords travel back to the idle stance (tiny overshoot past idle, then settle exactly on idle).
 *                  Interrupted by a new sprint, it turns into SPRINT_ENTER from the CURRENT weight.
 *
 * Every transition starts from the weight the animation currently has, so nothing ever snaps. Each main move
 * also ramps up from zero speed (no velocity jump at its start) and a short release grace keeps one-tick sprint
 * drops (hitting something, brushing a wall) from restarting the animation.
 * Animation language (meant for later states too): short anticipation -> snappy main move -> small overshoot
 * -> small settle -> secondary motion.
 */
public final class DualSwordAnimation {
    private static final float PI = (float) Math.PI;
    /** Vanilla walk cycle: arm pitch = cos(limbPos * 0.6662 ...). Using the same phase keeps us in sync with the arms. */
    private static final float LIMB_PHASE = 0.6662f;

    public enum State {
        IDLE, SPRINT_ENTER, SPRINT, SPRINT_EXIT
    }

    /** Entity -> its current animation track. Weak so unloaded players vanish. */
    private static final Map<Entity, Track> TRACKS = new WeakHashMap<>();

    private DualSwordAnimation() {
    }

    private static final class Track {
        State state;
        /** Time (ticks + partial tick) the current state started. */
        float start;
        /** Weight the current state started from (0 = idle pose, 1 = full sprint pose). */
        float from;
        /** Last time this track was updated; used to detect "not rendered for a while". */
        float last;
        /** Last time the player was actually sprinting (drives the release grace). */
        float lastSprint;
        /** Time the cached {@link #frame} was computed for; both hands ask in the same frame, so it is reused. */
        float frameNow = Float.NaN;
        Sprint frame;
    }

    /**
     * One frame of sprint animation (never exists for IDLE).
     *
     * @param state     SPRINT_ENTER, SPRINT or SPRINT_EXIT
     * @param ticks     time spent in the current state
     * @param blend     idle -> sprint weight: 0 = exact idle pose, 1 = exact sprint pose;
     *                  slightly below 0 / above 1 during anticipation and overshoot
     * @param phase     run-cycle phase in radians, in sync with the vanilla arm swing
     * @param intensity 0..1 how fast the player is moving (scales all secondary motion)
     */
    public record Sprint(State state, float ticks, float blend, float phase, float intensity) {
    }

    // ------------------------------------------------------------------ state machine

    /**
     * Advances this player's state machine to the current render time and returns the frame,
     * or null when the player is in IDLE (nothing to apply).
     * Safe to call several times per frame (first person calls it once per hand).
     */
    public static Sprint sprint(PlayerEntity player, float tickDelta) {
        boolean sprinting = player.isSprinting();
        float now = player.age + tickDelta;

        Track track = TRACKS.get(player);
        // not rendered for a while / time went backwards (world change): forget the old track
        if (track != null && (now < track.last - 1f || now - track.last > 4f)) {
            TRACKS.remove(player);
            track = null;
        }

        if (track == null) {
            if (!sprinting) {
                return null; // IDLE
            }
            track = begin(player, State.SPRINT_ENTER, now, 0f);
        } else if (track.frame != null && track.frameNow == now) {
            return track.frame; // second hand / second call in the same frame: nothing has changed
        }
        track.last = now;
        if (sprinting) {
            track.lastSprint = now;
        }
        // a sprint flag that dropped only for a moment (hit, wall) still counts as sprinting
        boolean active = sprinting || now - track.lastSprint < DualSwordTransforms.SPRINT_RELEASE_GRACE_TICKS;

        float enterTicks = Math.max(0.001f, DualSwordTransforms.SPRINT_ENTER_TICKS);
        float exitTicks = Math.max(0.001f, DualSwordTransforms.SPRINT_EXIT_TICKS);

        switch (track.state) {
            case SPRINT_ENTER -> {
                if (!active) {
                    track = begin(player, State.SPRINT_EXIT, now, weight(track, now));
                } else if (now - track.start >= enterTicks) {
                    track = begin(player, State.SPRINT, now, 1f);
                }
            }
            case SPRINT -> {
                if (!active) {
                    track = begin(player, State.SPRINT_EXIT, now, 1f);
                }
            }
            case SPRINT_EXIT -> {
                if (active) {
                    track = begin(player, State.SPRINT_ENTER, now, weight(track, now));
                } else if (now - track.start >= exitTicks) {
                    TRACKS.remove(player); // back to IDLE: the renderer now uses the existing idle pose
                    return null;
                }
            }
            default -> {
                TRACKS.remove(player);
                return null;
            }
        }
        track.last = now;

        float phase = player.limbAnimator.getPos(tickDelta) * LIMB_PHASE;
        float intensity = MathHelper.clamp(player.limbAnimator.getSpeed(tickDelta), 0f, 1f);
        Sprint frame = new Sprint(track.state, Math.max(0f, now - track.start), weight(track, now), phase, intensity);
        track.frameNow = now;
        track.frame = frame;
        return frame;
    }

    private static Track begin(PlayerEntity player, State state, float now, float from) {
        Track t = new Track();
        t.state = state;
        t.start = now;
        t.from = from;
        t.last = now;
        Track previous = TRACKS.put(player, t);
        // the grace timer survives a state change (otherwise ENTER -> EXIT would forget that we were just sprinting)
        t.lastSprint = previous != null ? previous.lastSprint : now;
        return t;
    }

    // ------------------------------------------------------------------ curves

    /** Idle -> sprint weight of a track at time {@code now}. */
    private static float weight(Track t, float now) {
        float elapsed = Math.max(0f, now - t.start);
        switch (t.state) {
            case SPRINT_ENTER: {
                float u = MathHelper.clamp(elapsed / Math.max(0.001f, DualSwordTransforms.SPRINT_ENTER_TICKS), 0f, 1f);
                float span = MathHelper.clamp(DualSwordTransforms.SPRINT_ENTER_ANTICIPATION_SPAN, 0.05f, 0.9f);
                // tiny wind-up away from the sprint pose ...
                float dip = t.from - DualSwordTransforms.SPRINT_ENTER_ANTICIPATION * (1f - t.from);
                if (u < span) {
                    return t.from + (dip - t.from) * smooth(u / span);
                }
                // ... then the snappy main move with a small overshoot, landing exactly on 1
                float m = (u - span) / (1f - span);
                return dip + (1f - dip) * easeOutBack(rampStart(m), DualSwordTransforms.SPRINT_ENTER_OVERSHOOT);
            }
            case SPRINT:
                return 1f;
            case SPRINT_EXIT: {
                float u = MathHelper.clamp(elapsed / Math.max(0.001f, DualSwordTransforms.SPRINT_EXIT_TICKS), 0f, 1f);
                // passes idle slightly (negative weight), then settles exactly on 0 = idle
                return t.from * (1f - easeOutBack(rampStart(u), DualSwordTransforms.SPRINT_EXIT_OVERSHOOT));
            }
            default:
                return 0f;
        }
    }

    static float smooth(float u) {
        u = MathHelper.clamp(u, 0f, 1f);
        return u * u * (3f - 2f * u);
    }

    /**
     * Re-times u (0..1) so the move starts at zero speed: a short quadratic ramp, then exactly the old linear
     * pace, still ending on 1. Without it easeOutBack starts at full speed, which reads as a kick (and as a
     * speed jump at the end of the wind-up). Same duration; only the first ~0.2 tick is gentler.
     */
    private static float rampStart(float u) {
        float a = MathHelper.clamp(DualSwordTransforms.SPRINT_MOVE_RAMP, 0f, 0.9f);
        u = MathHelper.clamp(u, 0f, 1f);
        if (a <= 0f) {
            return u;
        }
        float k = 1f / (1f - 0.5f * a);
        return u < a ? k * u * u / (2f * a) : k * (u - 0.5f * a);
    }

    /** Fast start, small overshoot past 1, settles on exactly 1 at u = 1. */
    static float easeOutBack(float u, float s) {
        u = MathHelper.clamp(u, 0f, 1f);
        float x = u - 1f;
        return 1f + (s + 1f) * x * x * x + s * x * x;
    }

    // ------------------------------------------------------------------ poses

    /** First person: idle pose blended toward the sprint pose, plus a small run bob. */
    public static Pose firstPersonPose(Arm arm, Sprint s) {
        Pose idle = DualSwordTransforms.firstPerson(arm);
        Pose target = arm == Arm.RIGHT
                ? DualSwordTransforms.FIRST_PERSON_RIGHT_SPRINT
                : DualSwordTransforms.FIRST_PERSON_LEFT_SPRINT_BACK;
        Pose p = Pose.lerp(idle, target, s.blend());

        float k = s.intensity() * MathHelper.clamp(s.blend(), 0f, 1f);
        float bobAmp = arm == Arm.RIGHT
                ? DualSwordTransforms.FIRST_PERSON_RIGHT_BOB_Y
                : DualSwordTransforms.FIRST_PERSON_LEFT_BOB_Y;
        float bobY = MathHelper.cos(2f * s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG) * bobAmp * k;
        float pitch = MathHelper.cos(s.phase() + PI - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.FIRST_PERSON_BOB_PITCH_DEG * k;
        return p.offset(0f, bobY, 0f, pitch, 0f, 0f);
    }

    /** Third person, sword that stays in the hand (right): blended toward the low pose + lagging sway. */
    public static Pose thirdPersonHandPose(Arm arm, Sprint s) {
        Pose idle = DualSwordTransforms.thirdPerson(arm);
        Pose p = Pose.lerp(idle, DualSwordTransforms.THIRD_PERSON_RIGHT_SPRINT, s.blend());

        float k = s.intensity() * MathHelper.clamp(s.blend(), 0f, 1f);
        // the arm already swings the sword; this lags slightly behind it (follow-through)
        float sway = MathHelper.cos(s.phase() + PI - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.THIRD_PERSON_RIGHT_SWAY_DEG * k;
        float bobY = MathHelper.cos(2f * s.phase()) * DualSwordTransforms.THIRD_PERSON_RIGHT_BOB_Y * k;
        return p.offset(0f, bobY, 0f, sway, 0f, 0f);
    }
}
