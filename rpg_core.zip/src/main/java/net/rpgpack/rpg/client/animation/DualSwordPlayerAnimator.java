package net.rpgpack.rpg.client.animation;

import dev.kosmx.playerAnim.api.layered.AnimationStack;
import dev.kosmx.playerAnim.core.animation.KeyframeAnimation;
import dev.kosmx.playerAnim.core.player.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;
import net.rpgpack.rpg.item.DualSwordItem;

import java.util.Map;
import java.util.WeakHashMap;

/** Thin RPG-owned trigger/selector; PlayerAnimator owns playback and interpolation. */
public final class DualSwordPlayerAnimator {
    private static final int ATTACK_LAYER = 2000;
    private static final int COMBO_RESET_TICKS = 24;
    private static final Identifier ATTACK_RIGHT = new Identifier(Rpg.MOD_ID, "dual_sword_attack_right");
    private static final Identifier ATTACK_LEFT = new Identifier(Rpg.MOD_ID, "dual_sword_attack_left");
    private static final Map<AbstractClientPlayerEntity, AttackState> STATES = new WeakHashMap<>();

    private static final class AttackState {
        Arm lastArm;
        int lastAge = Integer.MIN_VALUE;
    }

    private DualSwordPlayerAnimator() {}

    public static void onSwing(AbstractClientPlayerEntity player, Hand hand) {
        if (!(player.getMainHandStack().getItem() instanceof DualSwordItem)) return;

        int age = player.age;
        AttackState state = STATES.computeIfAbsent(player, ignored -> new AttackState());
        if (state.lastAge == age && state.lastArm != null) return;

        Arm main = player.getMainArm();
        boolean both = player.getOffHandStack().isEmpty();
        Arm arm;
        if (!both) {
            arm = main;
        } else if (hand == Hand.OFF_HAND) {
            arm = main.getOpposite();
        } else if (state.lastArm == null || age - state.lastAge > COMBO_RESET_TICKS) {
            arm = main;
        } else {
            arm = state.lastArm.getOpposite();
        }

        Identifier animationId = arm == Arm.RIGHT ? ATTACK_RIGHT : ATTACK_LEFT;
        var animation = PlayerAnimationRegistry.getAnimation(animationId);
        if (animation == null) return;

        AnimationStack stack = PlayerAnimationAccess.getPlayerAnimLayer(player);
        stack.removeLayer(ATTACK_LAYER);
        stack.addAnimLayer(ATTACK_LAYER, new KeyframeAnimationPlayer(animation));

        state.lastArm = arm;
        state.lastAge = age;
    }
}
