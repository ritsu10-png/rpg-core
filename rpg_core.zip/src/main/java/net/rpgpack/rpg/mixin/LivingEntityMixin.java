package net.rpgpack.rpg.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.rpgpack.rpg.client.animation.dualsword.DualSwordAttackTrigger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The attack trigger. Every client-side swing - the local player's click (hit or miss) and the swing packet of
 * other players - goes through LivingEntity#swingHand(Hand, boolean). At its end, handSwingTicks == -1 means this
 * call really started (or restarted) a swing, exactly like vanilla's own condition. Anything that is not a client
 * player returns on the first line.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "swingHand(Lnet/minecraft/util/Hand;Z)V", at = @At("TAIL"))
    private void rpg$onSwing(Hand hand, boolean fromServerPlayer, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof AbstractClientPlayerEntity player && self.handSwinging && self.handSwingTicks == -1) {
            DualSwordAttackTrigger.onSwing(player, hand);
        }
    }
}
