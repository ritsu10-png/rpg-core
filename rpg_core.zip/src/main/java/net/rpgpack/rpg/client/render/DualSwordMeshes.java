package net.rpgpack.rpg.client.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds a 3D "handheld item" mesh (front + back face + per-pixel extruded edges, 1/16 thick, exactly like
 * vanilla item models) straight from a hand texture, WITHOUT modifying the texture. Meshes are cached
 * and cleared on resource reload.
 *
 * Mesh space: x/y in 0..1 (sprite plane), z centred at 0.5 (7.5/16 .. 8.5/16), same as vanilla item models.
 * Vertex layout (8 floats): x y z u v nx ny nz ; 4 vertices per quad.
 */
public final class DualSwordMeshes {
    private static final float Z_BACK = 7.5f / 16f;
    private static final float Z_FRONT = 8.5f / 16f;
    public static final int FLOATS_PER_VERTEX = 8;

    private static final Map<Identifier, Mesh> CACHE = new HashMap<>();

    private DualSwordMeshes() {
    }

    public record Mesh(float[] data, int quadCount) {
    }

    public static void clear() {
        CACHE.clear();
    }

    public static Mesh get(Identifier texture) {
        return CACHE.computeIfAbsent(texture, DualSwordMeshes::build);
    }

    private static Mesh build(Identifier texture) {
        boolean[][] opaque = null;
        int w = 1;
        int h = 1;
        try (InputStream in = MinecraftClient.getInstance().getResourceManager().open(texture);
             NativeImage img = NativeImage.read(in)) {
            w = img.getWidth();
            h = img.getHeight();
            opaque = new boolean[w][h];
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    opaque[x][y] = ((img.getColor(x, y) >>> 24) & 0xFF) != 0;
                }
            }
        } catch (IOException | RuntimeException e) {
            Rpg.LOGGER.warn("Could not read hand texture {} - using flat quad", texture, e);
            opaque = null;
        }

        List<float[]> quads = new ArrayList<>();

        // front + back faces (full sprite; transparent texels are discarded by the cutout shader)
        addFace(quads, Z_FRONT, 1f);
        addFace(quads, Z_BACK, -1f);

        if (opaque != null) {
            for (int px = 0; px < w; px++) {
                for (int py = 0; py < h; py++) {
                    if (!opaque[px][py]) {
                        continue;
                    }
                    float x0 = px / (float) w;
                    float x1 = (px + 1) / (float) w;
                    float y0 = 1f - (py + 1) / (float) h; // lower edge (texture rows go downwards)
                    float y1 = 1f - py / (float) h;       // upper edge
                    float u = (px + 0.5f) / w;
                    float v = (py + 0.5f) / h;

                    if (px == 0 || !opaque[px - 1][py]) { // left edge
                        quads.add(quad(-1f, 0f, 0f,
                                new float[]{x0, y0, Z_BACK, u, v}, new float[]{x0, y0, Z_FRONT, u, v},
                                new float[]{x0, y1, Z_FRONT, u, v}, new float[]{x0, y1, Z_BACK, u, v}));
                    }
                    if (px == w - 1 || !opaque[px + 1][py]) { // right edge
                        quads.add(quad(1f, 0f, 0f,
                                new float[]{x1, y0, Z_FRONT, u, v}, new float[]{x1, y0, Z_BACK, u, v},
                                new float[]{x1, y1, Z_BACK, u, v}, new float[]{x1, y1, Z_FRONT, u, v}));
                    }
                    if (py == 0 || !opaque[px][py - 1]) { // top edge
                        quads.add(quad(0f, 1f, 0f,
                                new float[]{x0, y1, Z_BACK, u, v}, new float[]{x1, y1, Z_BACK, u, v},
                                new float[]{x1, y1, Z_FRONT, u, v}, new float[]{x0, y1, Z_FRONT, u, v}));
                    }
                    if (py == h - 1 || !opaque[px][py + 1]) { // bottom edge
                        quads.add(quad(0f, -1f, 0f,
                                new float[]{x0, y0, Z_FRONT, u, v}, new float[]{x1, y0, Z_FRONT, u, v},
                                new float[]{x1, y0, Z_BACK, u, v}, new float[]{x0, y0, Z_BACK, u, v}));
                    }
                }
            }
        }

        float[] data = new float[quads.size() * 4 * FLOATS_PER_VERTEX];
        for (int i = 0; i < quads.size(); i++) {
            System.arraycopy(quads.get(i), 0, data, i * 4 * FLOATS_PER_VERTEX, 4 * FLOATS_PER_VERTEX);
        }
        return new Mesh(data, quads.size());
    }

    private static void addFace(List<float[]> out, float z, float nz) {
        out.add(quad(0f, 0f, nz,
                new float[]{0f, 0f, z, 0f, 1f}, new float[]{1f, 0f, z, 1f, 1f},
                new float[]{1f, 1f, z, 1f, 0f}, new float[]{0f, 1f, z, 0f, 0f}));
    }

    /** Each vertex array is {x, y, z, u, v}. */
    private static float[] quad(float nx, float ny, float nz, float[] a, float[] b, float[] c, float[] d) {
        float[] out = new float[4 * FLOATS_PER_VERTEX];
        float[][] vs = {a, b, c, d};
        for (int i = 0; i < 4; i++) {
            int o = i * FLOATS_PER_VERTEX;
            System.arraycopy(vs[i], 0, out, o, 5);
            out[o + 5] = nx;
            out[o + 6] = ny;
            out[o + 7] = nz;
        }
        return out;
    }
}
