package net.rpgpack.rpg.client.animation;

/**
 * How the segment from a keyframe to the NEXT keyframe is travelled. {@link #apply} remaps the segment progress
 * u (0..1) to the blend weight; CATMULL_ROM is the exception: {@link AnimationTrack} builds a curve through the
 * neighbouring keyframes for it (u is used as is).
 */
public enum Interpolation {
    /** Constant speed. */
    LINEAR,
    /** Slow in, slow out (smoothstep). Weight and settle. */
    SMOOTH,
    /** Starts at rest and accelerates: the strike runs into the impact at full speed. */
    EASE_IN,
    /** Starts fast and decelerates to rest: overshoot / landing in a pose. */
    EASE_OUT,
    /** Smooth curve through the neighbouring keyframes (no stop at the key). Flowing follow-through and recovery. */
    CATMULL_ROM,
    /** Holds the keyframe's pose, then jumps to the next one when it is reached. */
    STEP;

    public float apply(float u) {
        switch (this) {
            case SMOOTH:
                return u * u * (3f - 2f * u);
            case EASE_IN:
                return u * u * u;
            case EASE_OUT: {
                float k = 1f - u;
                return 1f - k * k * k;
            }
            case STEP:
                return u < 1f ? 0f : 1f;
            default:
                return u;
        }
    }
}
