package net.rpgpack.rpg.client.animation;

/**
 * Plays ONE clip at a time. The timeline is tick based and deterministic: {@link #tick()} (once per client tick)
 * moves the clock by {@code speed} ticks, and {@link #sample} interpolates between the previous and the current
 * clock with the render partial tick, so the motion is smooth at any frame rate. No wall-clock, no render-time
 * guessing: the same sequence of play()/tick() always gives the same poses.
 *
 * speed 1 = the clip's own length in ticks, 2 = twice as fast, 0.5 = half speed (keyframes never change).
 * When a clip is started while another one is still playing, the pose at that moment is captured and faded into
 * the new clip over {@code fadeTicks} (no snap).
 * Finished or stopped = not playing = the caller falls back to the base pose.
 */
public final class AnimationPlayer {
    private Animation animation;
    private float speed = 1f;
    private float time;
    private float prevTime;
    private boolean playing;

    private final PoseBuffer fadeFrom = new PoseBuffer();
    private boolean fading;
    private float fadeTicks;
    private float fadeTime;
    private float fadePrevTime;

    public void play(Animation next, float speed, float fadeTicks) {
        fading = false;
        if (playing && fadeTicks > 0f) {
            animation.evaluate(time, fadeFrom);
            fading = true;
            this.fadeTicks = fadeTicks;
            fadeTime = 0f;
            fadePrevTime = 0f;
        }
        animation = next;
        this.speed = Math.max(0.01f, speed);
        time = 0f;
        prevTime = 0f;
        playing = true;
    }

    public void stop() {
        playing = false;
        fading = false;
    }

    /** Once per client tick. */
    public void tick() {
        if (!playing) {
            return;
        }
        if (fading) {
            fadePrevTime = fadeTime;
            fadeTime += 1f;
            if (fadePrevTime >= fadeTicks) {
                fading = false;
            }
        }
        prevTime = time;
        if (prevTime >= animation.lengthTicks()) {
            playing = false; // the previous tick already showed the final pose
            fading = false;
            return;
        }
        time += speed;
    }

    public boolean isPlaying() {
        return playing;
    }

    public Animation animation() {
        return playing ? animation : null;
    }

    public float speed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = Math.max(0.01f, speed);
    }

    /** Normalised progress 0..1 of the clip (0 when not playing). */
    public float progress(float tickDelta) {
        if (!playing) {
            return 0f;
        }
        float t = prevTime + (time - prevTime) * tickDelta;
        return Math.min(1f, Math.max(0f, t / animation.lengthTicks()));
    }

    /**
     * Writes the clip's pose at this render frame into {@code out}. Returns false (out = neutral pose) when
     * nothing is playing.
     */
    public boolean sample(float tickDelta, PoseBuffer out) {
        if (!playing) {
            out.setIdentity();
            return false;
        }
        float t = prevTime + (time - prevTime) * tickDelta;
        animation.evaluate(Math.max(0f, t), out);
        if (fading) {
            float f = (fadePrevTime + (fadeTime - fadePrevTime) * tickDelta) / fadeTicks;
            if (f < 1f) {
                out.lerp(fadeFrom, out, Interpolation.SMOOTH.apply(Math.max(0f, f)));
            }
        }
        return true;
    }
}
