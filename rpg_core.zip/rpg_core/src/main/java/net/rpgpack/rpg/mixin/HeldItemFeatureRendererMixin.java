package net.rpgpack.rpg.mixin;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.ModelWithArms;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.rpgpack.rpg.client.render.DualSwordRenderer;
import net.rpgpack.rpg.item.DualSwordItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Third person. Vanilla renders the main-hand stack on the main arm; when that stack is a Dual Sword we
 * replace it with the two-sword representation (second sword only if the off hand is empty).
 */
@Mixin(HeldItemFeatureRenderer.class)
public abstract class HeldItemFeatureRendererMixin<T extends LivingEntity, M extends EntityModel<T> & ModelWithArms>
        extends FeatureRenderer<T, M> {

    public HeldItemFeatureRendererMixin(FeatureRendererContext<T, M> context) {
        super(context);
    }

    @Inject(method = "renderItem", at = @At("HEAD"), cancellable = true)
    private void rpg$renderDualSword(LivingEntity entity, ItemStack stack, ModelTransformationMode mode, Arm arm,
                                     MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                     CallbackInfo ci) {
        if (!(stack.getItem() instanceof DualSwordItem dual)) {
            return;
        }
        // only the MAIN hand stack on the MAIN arm is converted; a Dual Sword in the off hand stays vanilla
        if (stack != entity.getMainHandStack() || arm != entity.getMainArm()) {
            return;
        }

        boolean both = entity.getOffHandStack().isEmpty();
        DualSwordRenderer.renderThirdPerson(this.getContextModel(), matrices, vertexConsumers, light,
                dual.getMaterial(), arm, both);
        ci.cancel();
    }
}
