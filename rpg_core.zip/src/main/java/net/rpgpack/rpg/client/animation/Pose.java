package net.rpgpack.rpg.client.animation;

/**
 * Immutable value object: position (1/16 block), rotation (degrees, applied X then Y then Z like vanilla item
 * display transforms) and scale, each on three axes.
 *
 * Used for two things, always as a VALUE (nothing here is ever modified in place):
 *  - a BASE pose (where the weapon sits in the hand), absolute;
 *  - an ANIMATION pose (keyframes), a DELTA from the base: {@link #IDENTITY} (0 / 0 / scale 1) means "no change".
 */
public final class Pose {
    public static final int CHANNELS = 9;
    public static final int POS_X = 0, POS_Y = 1, POS_Z = 2;
    public static final int ROT_X = 3, ROT_Y = 4, ROT_Z = 5;
    public static final int SCALE_X = 6, SCALE_Y = 7, SCALE_Z = 8;

    /** Neutral animation pose: no offset, no rotation, scale 1. */
    public static final Pose IDENTITY = of(0f, 0f, 0f, 0f, 0f, 0f);

    private final float[] v; // never exposed

    private Pose(float[] v) {
        this.v = v;
    }

    public static Pose of(float px, float py, float pz, float rx, float ry, float rz, float sx, float sy, float sz) {
        return new Pose(new float[]{px, py, pz, rx, ry, rz, sx, sy, sz});
    }

    public static Pose of(float px, float py, float pz, float rx, float ry, float rz, float uniformScale) {
        return of(px, py, pz, rx, ry, rz, uniformScale, uniformScale, uniformScale);
    }

    public static Pose of(float px, float py, float pz, float rx, float ry, float rz) {
        return of(px, py, pz, rx, ry, rz, 1f, 1f, 1f);
    }

    public float channel(int index) {
        return v[index];
    }

    public float posX() { return v[POS_X]; }
    public float posY() { return v[POS_Y]; }
    public float posZ() { return v[POS_Z]; }
    public float rotX() { return v[ROT_X]; }
    public float rotY() { return v[ROT_Y]; }
    public float rotZ() { return v[ROT_Z]; }
    public float scaleX() { return v[SCALE_X]; }
    public float scaleY() { return v[SCALE_Y]; }
    public float scaleZ() { return v[SCALE_Z]; }

    /**
     * Mirror across the plane x = 0 (swap left/right): X position and the Y/Z rotations change sign,
     * the X rotation and the scale stay. Handy as a starting point for the other hand's keyframes.
     */
    public Pose mirrorX() {
        return of(-v[POS_X], v[POS_Y], v[POS_Z], v[ROT_X], -v[ROT_Y], -v[ROT_Z], v[SCALE_X], v[SCALE_Y], v[SCALE_Z]);
    }
}
