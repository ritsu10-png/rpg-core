package net.rpgpack.rpg.client.render;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.rpgpack.rpg.client.render.DualSwordTransforms.Pose;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Client-side animation STATE + CURVES for the Dual Sword (PLAYER only). All tunable numbers live in
 * {@link DualSwordTransforms}; this class only turns "how long has the player been sprinting" into poses.
 *
 * Animation language used here (and meant for the next states too):
 * short anticipation -> snappy main move -> small overshoot -> small settle/bounce -> secondary motion.
 *
 * Current states: IDLE (no state, existing poses untouched) and SPRINT.
 * Leaving SPRINT drops the state immediately, so the renderer falls straight back to the idle pose.
 */
public final class DualSwordAnimation {
    private static final float PI = (float) Math.PI;
    /** Vanilla walk cycle: arm pitch = cos(limbPos * 0.6662 ...). Using the same phase keeps us in sync with the arms. */
    private static final float LIMB_PHASE = 0.6662f;

    /** Entity -> when its current sprint started (in ticks + partial tick). Weak so unloaded players vanish. */
    private static final Map<Entity, Track> TRACKS = new WeakHashMap<>();

    private DualSwordAnimation() {
    }

    private static final class Track {
        float start;
        float last;
    }

    /**
     * One frame of sprint animation.
     *
     * @param ticks     time since the sprint started
     * @param blend     idle -> sprint weight for the right/hand poses; dips below 0 (anticipation) and above 1 (overshoot)
     * @param sheathed  false during the wind-up: the left sword is still in the hand
     * @param backBlend entry -> back weight for the left sword once sheathed (starts at 0, overshoots, settles at 1)
     * @param dip       0..1 wind-up progress of the left sword while it is still in the hand
     * @param phase     run-cycle phase in radians, in sync with the vanilla arm swing
     * @param intensity 0..1 how fast the player is moving (scales all secondary motion)
     */
    public record Sprint(float ticks, float blend, boolean sheathed, float backBlend, float dip, float phase,
                         float intensity) {
    }

    // ------------------------------------------------------------------ state

    /** Returns the current sprint frame, or null when the player is not sprinting (= IDLE, nothing to apply). */
    public static Sprint sprint(PlayerEntity player, float tickDelta) {
        if (!player.isSprinting()) {
            TRACKS.remove(player);
            return null;
        }

        float now = player.age + tickDelta;
        Track track = TRACKS.get(player);
        // new sprint, or the player was not rendered for a while / time went backwards -> restart the intro
        if (track == null || now < track.last - 1f || now - track.last > 4f) {
            track = new Track();
            track.start = now;
            TRACKS.put(player, track);
        }
        track.last = now;

        float ticks = Math.max(0f, now - track.start);
        float anticipation = DualSwordTransforms.SPRINT_ANTICIPATION_TICKS;
        boolean sheathed = ticks >= anticipation;

        float dip = smooth(ticks / Math.max(0.001f, anticipation));
        float blend = sprintBlend(ticks);
        float backBlend = sheathed ? snap(ticks - anticipation, 0f) : 0f;

        float phase = player.limbAnimator.getPos(tickDelta) * LIMB_PHASE;
        float intensity = MathHelper.clamp(player.limbAnimator.getSpeed(tickDelta), 0f, 1f);
        return new Sprint(ticks, blend, sheathed, backBlend, dip, phase, intensity);
    }

    // ------------------------------------------------------------------ curves

    private static float smooth(float u) {
        u = MathHelper.clamp(u, 0f, 1f);
        return u * u * (3f - 2f * u);
    }

    /** Wind-up dip (to -ANTICIPATION_DEPTH), then the snap/overshoot/settle. */
    static float sprintBlend(float ticks) {
        float a = DualSwordTransforms.SPRINT_ANTICIPATION_TICKS;
        float dip = -DualSwordTransforms.SPRINT_ANTICIPATION_DEPTH;
        if (ticks < a) {
            return dip * smooth(ticks / Math.max(0.001f, a));
        }
        return snap(ticks - a, dip);
    }

    /**
     * Fast ease-out from {@code from} to slightly past 1, then a damped settle back to exactly 1.
     * {@code tb} is the time since the main move started.
     */
    static float snap(float tb, float from) {
        float snapTicks = Math.max(0.001f, DualSwordTransforms.SPRINT_SNAP_TICKS);
        float settleTicks = Math.max(0.001f, DualSwordTransforms.SPRINT_SETTLE_TICKS);
        float over = DualSwordTransforms.SPRINT_OVERSHOOT;

        if (tb <= 0f) {
            return from;
        }
        if (tb < snapTicks) {
            float u = tb / snapTicks;
            float ease = 1f - (1f - u) * (1f - u) * (1f - u); // cubic ease-out = snappy
            return from + (1f + over - from) * ease;
        }
        if (tb < snapTicks + settleTicks) {
            float u = (tb - snapTicks) / settleTicks;
            float d = 1f - u;
            return 1f + over * d * d * MathHelper.cos(u * 2f * PI); // damped, tiny bounce below 1
        }
        return 1f;
    }

    // ------------------------------------------------------------------ poses

    /** First person: idle pose blended toward the sprint pose, plus a small run bob. */
    public static Pose firstPersonPose(Arm arm, Sprint s) {
        Pose idle = DualSwordTransforms.firstPerson(arm);
        Pose target = arm == Arm.RIGHT
                ? DualSwordTransforms.FIRST_PERSON_RIGHT_SPRINT
                : DualSwordTransforms.FIRST_PERSON_LEFT_SPRINT_BACK;
        Pose p = Pose.lerp(idle, target, s.blend());

        float k = s.intensity() * MathHelper.clamp(s.blend(), 0f, 1f);
        float bobAmp = arm == Arm.RIGHT
                ? DualSwordTransforms.FIRST_PERSON_RIGHT_BOB_Y
                : DualSwordTransforms.FIRST_PERSON_LEFT_BOB_Y;
        float bobY = MathHelper.cos(2f * s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG) * bobAmp * k;
        float pitch = MathHelper.cos(s.phase() + PI - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.FIRST_PERSON_BOB_PITCH_DEG * k;
        return p.offset(0f, bobY, 0f, pitch, 0f, 0f);
    }

    /** Third person, sword that stays in the hand (right): blended toward the low pose + lagging sway. */
    public static Pose thirdPersonHandPose(Arm arm, Sprint s) {
        Pose idle = DualSwordTransforms.thirdPerson(arm);
        Pose p = Pose.lerp(idle, DualSwordTransforms.THIRD_PERSON_RIGHT_SPRINT, s.blend());

        float k = s.intensity() * MathHelper.clamp(s.blend(), 0f, 1f);
        // the arm already swings the sword; this lags slightly behind it (follow-through)
        float sway = MathHelper.cos(s.phase() + PI - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.THIRD_PERSON_RIGHT_SWAY_DEG * k;
        float bobY = MathHelper.cos(2f * s.phase()) * DualSwordTransforms.THIRD_PERSON_RIGHT_BOB_Y * k;
        return p.offset(0f, bobY, 0f, sway, 0f, 0f);
    }

    /** Third person, left sword during the wind-up (still in the hand, dipping before it is sheathed). */
    public static Pose thirdPersonLeftWindUp(Sprint s) {
        return Pose.lerp(DualSwordTransforms.thirdPerson(Arm.LEFT),
                DualSwordTransforms.THIRD_PERSON_LEFT_ANTICIPATION, s.dip());
    }

    /** Third person, left sword on the back (body-part space): entry -> back pose + subtle follow-through. */
    public static Pose backPose(Sprint s) {
        Pose p = Pose.lerp(DualSwordTransforms.BACK_SWORD_ENTRY, DualSwordTransforms.BACK_SWORD, s.backBlend());

        float k = s.intensity() * MathHelper.clamp(s.backBlend(), 0f, 1f);
        // the torso bounces at footfall rate; the sword follows a touch later and sways across the back
        float bobY = MathHelper.cos(2f * s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.BACK_BOB_Y * k;
        float swayX = MathHelper.sin(s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.BACK_SWAY_X * k;
        float swayRot = MathHelper.sin(s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.BACK_SWAY_DEG * k;
        return p.offset(swayX, bobY, 0f, 0f, 0f, swayRot);
    }
}
