package net.rpgpack.rpg.client.animation;

/**
 * Playback of ONE clip on ONE slot (for example one arm's sword). Holds only the playback clock, so it works for
 * any weapon. Not playing = the neutral pose.
 *
 * Starting a clip while another one is still playing never snaps: the pose at that moment is captured and
 * cross-faded into the new clip over a few ticks (deterministic "interrupt").
 */
public final class AnimationState {
    private Animation animation;
    private float startTime;
    private boolean blending;
    private float blendTicks;
    private final PoseBuffer blendFrom = new PoseBuffer();

    /** Starts {@code next} at time {@code now} (ticks), replacing whatever is playing. */
    public void play(Animation next, float now, float blendTicks) {
        blending = false;
        if (animation != null && sample(now, blendFrom)) {
            blending = blendTicks > 0f;
            this.blendTicks = blendTicks;
        }
        animation = next;
        startTime = now;
    }

    public void stop() {
        animation = null;
        blending = false;
    }

    /**
     * Writes the current pose into {@code out}. Returns false (and writes the neutral pose) when nothing is
     * playing or the clip has finished.
     */
    public boolean sample(float now, PoseBuffer out) {
        if (animation == null) {
            out.setIdentity();
            return false;
        }
        float elapsed = now - startTime;
        if (elapsed >= animation.lengthTicks()) {
            animation = null;
            blending = false;
            out.setIdentity();
            return false;
        }
        animation.evaluate(elapsed, out);
        if (blending) {
            if (elapsed >= blendTicks) {
                blending = false;
            } else {
                out.lerp(blendFrom, out, Interpolation.SMOOTH.apply(Math.max(0f, elapsed) / blendTicks));
            }
        }
        return true;
    }
}
