package net.rpgpack.rpg.client.render;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Third-person attack for a player holding a Dual Sword. Called from BipedEntityModelMixin after vanilla has
 * posed the model for this frame. Nothing here replaces vanilla: it adds a small wind-up / strike / recovery
 * offset to the SWINGING arm, a little torso twist, and re-places the arm pivots the way vanilla does.
 *
 * Source of truth is vanilla's own swing: {@code model.handSwingProgress} (0 = not swinging, 0..1 while swinging,
 * already interpolated by the renderer). That is the same swing the first-person view uses, so both stay in sync,
 * the duration follows haste / mining fatigue, and the state returns to IDLE by itself when the swing ends.
 * The swinging arm comes from {@code entity.preferredHand} (vanilla sets it on every swing): main hand = main arm,
 * off hand = the other arm.
 *
 * States (derived from the swing progress, nothing to tick or reset):
 * IDLE -> ATTACK_START -> ATTACK_SWING -> ATTACK_RECOVERY -> IDLE. Every phase boundary has zero speed and the
 * curve starts and ends on exactly 0, so there is no snap. An attack restarted before recovery ends
 * continues smoothly (vanilla's progress runs to 1.0, where the curve is 0, before it restarts).
 * Only a change of the swinging arm needs state: a short per-arm gain hands the motion over.
 */
public final class DualSwordAttackAnimation {
    public enum State {
        IDLE, ATTACK_START, ATTACK_SWING, ATTACK_RECOVERY
    }

    private static final float DEG = (float) (Math.PI / 180.0);
    private static final int RIGHT = 0;
    private static final int LEFT = 1;
    /** Offsets below this are not worth applying. */
    private static final float EPS = 0.001f;

    /** Entity -> per-swing state. Only exists while a swing is playing; weak so unloaded players vanish. */
    private static final Map<Entity, Track> TRACKS = new WeakHashMap<>();

    private DualSwordAttackAnimation() {
    }

    private static final class Track {
        /** Time (ticks + partial tick) of the last update; NaN until the first one. */
        float lastNow = Float.NaN;
        /** Arm that was swinging last frame, -1 = none yet. */
        int arm = -1;
        /** How much of the motion each arm currently takes (1 = all). Only differs from 0/1 while handing over. */
        final float[] gain = new float[2];
        /** The offset weight each arm was given last frame (to tell whether a hand-over has anything to smooth). */
        final float[] out = new float[2];
    }

    // ------------------------------------------------------------------ state + curve

    public static State state(float p) {
        if (p <= 0f) {
            return State.IDLE;
        }
        if (p < DualSwordTransforms.ATTACK_START_END) {
            return State.ATTACK_START;
        }
        return p < DualSwordTransforms.ATTACK_SWING_END ? State.ATTACK_SWING : State.ATTACK_RECOVERY;
    }

    /**
     * Attack weight for swing progress p: slightly negative in the wind-up, 1 at the end of the strike, back to
     * exactly 0 at p = 1. Smoothstep pieces, so every phase boundary has zero speed.
     */
    static float envelope(float p) {
        float a = MathHelper.clamp(DualSwordTransforms.ATTACK_START_END, 0.02f, 0.5f);
        float b = MathHelper.clamp(DualSwordTransforms.ATTACK_SWING_END, a + 0.05f, 0.9f);
        float w = Math.max(0f, DualSwordTransforms.ATTACK_WINDUP);
        switch (state(p)) {
            case ATTACK_START:
                return -w * DualSwordAnimation.smooth(p / a);
            case ATTACK_SWING:
                return -w + (1f + w) * DualSwordAnimation.smooth((p - a) / (b - a));
            case ATTACK_RECOVERY:
                return 1f - DualSwordAnimation.smooth((p - b) / (1f - b));
            default:
                return 0f;
        }
    }

    // ------------------------------------------------------------------ apply

    /** Adds the attack offsets to {@code model} (already posed by vanilla for this frame). Cheap no-op when idle. */
    public static void apply(BipedEntityModel<?> model, LivingEntity entity, float now) {
        float p = model.handSwingProgress;
        if (p <= 0f) {
            // IDLE: forget a finished swing; the common case costs one isEmpty() check
            if (!TRACKS.isEmpty()) {
                TRACKS.remove(entity);
            }
            return;
        }
        if (DualSwordRenderer.getMainHandDualSword(entity) == null) {
            if (!TRACKS.isEmpty()) {
                TRACKS.remove(entity);
            }
            return; // not holding a Dual Sword: vanilla only
        }

        Track t = TRACKS.get(entity);
        if (t == null) {
            t = new Track();
            TRACKS.put(entity, t);
        }
        int arm = swingingArm(entity);
        if (t.lastNow != now) { // once per frame (setAngles can run more than once for the same frame)
            advance(t, arm, now);
        }

        float e = envelope(p);
        float wRight = DualSwordAnimation.smooth(t.gain[RIGHT]) * e;
        float wLeft = DualSwordAnimation.smooth(t.gain[LEFT]) * e;
        t.out[RIGHT] = wRight;
        t.out[LEFT] = wLeft;
        if (Math.abs(wRight) < EPS && Math.abs(wLeft) < EPS) {
            return;
        }

        float torso = 0f;
        if (Math.abs(wRight) >= EPS) {
            shapeArm(model.rightArm, 1f, wRight);
            torso -= wRight;
        }
        if (Math.abs(wLeft) >= EPS) {
            shapeArm(model.leftArm, -1f, wLeft);
            torso += wLeft;
        }
        model.body.yaw += torso * DualSwordTransforms.ATTACK_TORSO_YAW_DEG * DEG;

        // vanilla keeps the shoulders on the twisting torso like this (BipedEntityModel#animateArms)
        float sin = MathHelper.sin(model.body.yaw);
        float cos = MathHelper.cos(model.body.yaw);
        model.rightArm.pivotZ = sin * 5.0f;
        model.rightArm.pivotX = -cos * 5.0f;
        model.leftArm.pivotZ = -sin * 5.0f;
        model.leftArm.pivotX = cos * 5.0f;
    }

    /** Extra pose of the swinging arm. dir = +1 right arm, -1 left arm (mirrors yaw / roll). */
    private static void shapeArm(ModelPart arm, float dir, float w) {
        arm.pitch -= w * DualSwordTransforms.ATTACK_ARM_PITCH_DEG * DEG;
        arm.yaw -= dir * w * DualSwordTransforms.ATTACK_ARM_YAW_DEG * DEG;
        arm.roll -= dir * w * DualSwordTransforms.ATTACK_ARM_ROLL_DEG * DEG;
    }

    /** Main hand swings the main arm, off hand swings the other one. Same rule vanilla uses for the swing itself. */
    private static int swingingArm(LivingEntity entity) {
        Arm main = entity.getMainArm();
        Arm arm = entity.preferredHand == Hand.MAIN_HAND ? main : main.getOpposite();
        return arm == Arm.RIGHT ? RIGHT : LEFT;
    }

    /** Hands the motion to the arm that is swinging now. Instant when the other arm has nothing on screen. */
    private static void advance(Track t, int arm, float now) {
        int other = 1 - arm;
        if (t.arm != arm) {
            if (t.arm < 0 || Math.abs(t.out[other]) < 0.02f) {
                t.gain[arm] = 1f; // nothing to hand over from: full strength right away (responsive start)
                t.gain[other] = 0f;
            }
            t.arm = arm;
        }
        float dt = Float.isNaN(t.lastNow) ? 1f : MathHelper.clamp(now - t.lastNow, 0f, 1f);
        float step = dt / Math.max(0.001f, DualSwordTransforms.ATTACK_ARM_SWITCH_TICKS);
        t.gain[arm] = Math.min(1f, t.gain[arm] + step);
        t.gain[other] = Math.max(0f, t.gain[other] - step);
        t.lastNow = now;
    }
}
