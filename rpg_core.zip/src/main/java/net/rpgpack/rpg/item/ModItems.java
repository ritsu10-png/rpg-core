package net.rpgpack.rpg.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    private static final Map<DualSwordMaterial, DualSwordItem> DUAL_SWORDS = new EnumMap<>(DualSwordMaterial.class);

    public static final DualSwordItem DUAL_SWORD_WOOD = registerDualSword(DualSwordMaterial.WOOD);
    public static final DualSwordItem DUAL_SWORD_STONE = registerDualSword(DualSwordMaterial.STONE);
    public static final DualSwordItem DUAL_SWORD_COPPER = registerDualSword(DualSwordMaterial.COPPER);
    public static final DualSwordItem DUAL_SWORD_IRON = registerDualSword(DualSwordMaterial.IRON);
    public static final DualSwordItem DUAL_SWORD_GOLD = registerDualSword(DualSwordMaterial.GOLD);
    public static final DualSwordItem DUAL_SWORD_DIAMOND = registerDualSword(DualSwordMaterial.DIAMOND);
    public static final DualSwordItem DUAL_SWORD_NETHERITE = registerDualSword(DualSwordMaterial.NETHERITE);

    private ModItems() {
    }

    private static DualSwordItem registerDualSword(DualSwordMaterial material) {
        DualSwordItem item = new DualSwordItem(new Item.Settings().maxCount(1), material);
        Registry.register(Registries.ITEM, new Identifier(Rpg.MOD_ID, material.itemName()), item);
        DUAL_SWORDS.put(material, item);
        return item;
    }

    /** Called from the mod initializer to force class loading (and therefore registration). */
    public static void register() {
        // Convenience for testing only: lists the swords in the vanilla Combat tab.
        // (Not required; /give rpg:dual_sword_diamond also works.)
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries ->
                DUAL_SWORDS.values().forEach(entries::add));
    }
}
