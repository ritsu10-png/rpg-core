package net.rpgpack.rpg.client.animation.dualsword;

import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;
import net.rpgpack.rpg.client.animation.Animation;
import net.rpgpack.rpg.client.animation.AnimationRegistry;
import net.rpgpack.rpg.client.animation.Interpolation;
import net.rpgpack.rpg.client.animation.Pose;

/**
 * Keyframe data of the Dual Sword clips. Static and immutable: built once, shared by every player.
 *
 * Every pose here is a DELTA from the sword's base pose (see DualSwordTransforms), so the first and last key are
 * Pose.IDENTITY and the clip starts and ends exactly in the idle stance.
 *
 * Axes (hand space, arm hanging down; see PoseApplier): +X player's right, +Y forward, +Z up along the arm.
 * Position in 1/16 block; rotation in degrees around the grip:
 *   rotX  > 0 raises the blade tip, < 0 drops it
 *   rotY  twists the blade around its own (forward) axis
 *   rotZ  swings the tip sideways: > 0 toward the player's left, < 0 toward the right
 * The numbers are a first pass meant to be tuned in game (timing first, then amplitude).
 *
 * Timeline (normalised time):
 *   0.00 idle -> 0.10 wind-up starts -> 0.20 loaded (anticipation peak, a little squashed)
 *   -> 0.30 IMPACT (fast, sword passes the idle line, small pop in scale)
 *   -> 0.42 follow-through (overshoot) -> 0.65 recovery (nearly home) -> 0.80 idle -> 1.00 idle
 */
public final class DualSwordAnimations {
    /** Length of one attack clip, in client ticks. Keep it at or below the usual attack interval. */
    public static final float ATTACK_TICKS = 8f;

    public static final Identifier ATTACK_RIGHT_ID = new Identifier(Rpg.MOD_ID, "dual_sword/attack_right");
    public static final Identifier ATTACK_LEFT_ID = new Identifier(Rpg.MOD_ID, "dual_sword/attack_left");

    /** Right arm: loads up and outward, then cuts down and across the body. */
    public static final Animation ATTACK_RIGHT = Animation.builder("dual_sword_attack_right", ATTACK_TICKS)
            .key(0.00f, Pose.IDENTITY, Interpolation.EASE_IN)
            .key(0.10f, Pose.of(0.6f, -1.0f, 0.8f, 22f, 10f, -8f), Interpolation.EASE_OUT)
            .key(0.20f, Pose.of(1.5f, -2.6f, 2.0f, 62f, 24f, -22f, 0.96f), Interpolation.EASE_IN)
            .key(0.30f, Pose.of(-1.5f, 4.0f, -2.0f, -34f, -20f, 34f, 1.08f), Interpolation.EASE_OUT)
            .key(0.42f, Pose.of(-2.2f, 5.0f, -2.8f, -48f, -26f, 44f, 1.02f), Interpolation.CATMULL_ROM)
            .key(0.65f, Pose.of(-0.4f, 1.0f, -0.5f, -8f, -5f, 9f), Interpolation.CATMULL_ROM)
            .key(0.80f, Pose.IDENTITY, Interpolation.LINEAR)
            .key(1.00f, Pose.IDENTITY, Interpolation.LINEAR)
            .build();

    /**
     * Left arm: the counterpart, not a sign-flipped copy. Same shape mirrored across the body, but the off-hand
     * is a little quicker (loaded 0.19, impact 0.28), a bit smaller up top and drops lower at the end.
     */
    public static final Animation ATTACK_LEFT = Animation.builder("dual_sword_attack_left", ATTACK_TICKS)
            .key(0.00f, Pose.IDENTITY, Interpolation.EASE_IN)
            .key(0.10f, Pose.of(-0.6f, -1.0f, 0.8f, 20f, -9f, 8f), Interpolation.EASE_OUT)
            .key(0.19f, Pose.of(-1.3f, -2.4f, 2.3f, 58f, -20f, 20f, 0.96f), Interpolation.EASE_IN)
            .key(0.28f, Pose.of(1.3f, 3.6f, -2.2f, -36f, 18f, -30f, 1.07f), Interpolation.EASE_OUT)
            .key(0.41f, Pose.of(2.0f, 4.6f, -3.0f, -50f, 24f, -40f, 1.02f), Interpolation.CATMULL_ROM)
            .key(0.65f, Pose.of(0.4f, 0.9f, -0.6f, -9f, 4f, -8f), Interpolation.CATMULL_ROM)
            .key(0.80f, Pose.IDENTITY, Interpolation.LINEAR)
            .key(1.00f, Pose.IDENTITY, Interpolation.LINEAR)
            .build();

    private DualSwordAnimations() {
    }

    /** Puts both clips in the registry (client start-up). */
    public static void register() {
        AnimationRegistry.register(ATTACK_RIGHT_ID, ATTACK_RIGHT);
        AnimationRegistry.register(ATTACK_LEFT_ID, ATTACK_LEFT);
    }
}
