package net.rpgpack.rpg.client.render;

import net.minecraft.util.Arm;

/**
 * SINGLE place that holds every tunable value for the Dual Sword hand rendering.
 *
 * Pose fields:
 *   x/y/z       translation in 1/16 block units (same units as item "display" JSON)
 *   rotX/Y/Z    rotation in degrees (applied X, then Y, then Z - same as vanilla item display transforms)
 *   scale       uniform scale
 *
 * The initial values start from vanilla's "item/handheld" display transforms (mirrored for the left hand),
 * which already put a sword sprite naturally in each hand. Tweak them here - nothing else needs to change.
 *
 * Future animation phases (idle stance, attack, skills, roll) can swap these Pose values at runtime
 * (the fields are non-final on purpose) or add more offsets next to the swing offsets below.
 */
public final class DualSwordTransforms {
    private DualSwordTransforms() {
    }

    public record Pose(float x, float y, float z, float rotX, float rotY, float rotZ, float scale) {
        /** Linear blend. {@code t} outside 0..1 extrapolates on purpose (anticipation / overshoot). */
        public static Pose lerp(Pose a, Pose b, float t) {
            return new Pose(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t,
                    a.rotX + (b.rotX - a.rotX) * t, a.rotY + (b.rotY - a.rotY) * t,
                    a.rotZ + (b.rotZ - a.rotZ) * t, a.scale + (b.scale - a.scale) * t);
        }

        /** This pose plus a translation (1/16 units) and a rotation (degrees) offset. */
        public Pose offset(float dx, float dy, float dz, float drx, float dry, float drz) {
            return new Pose(x + dx, y + dy, z + dz, rotX + drx, rotY + dry, rotZ + drz, scale);
        }
    }

    /** Extra translation (1/16 units) added while swinging, multiplied by sin(swingProgress * PI). */
    public record SwingOffset(float x, float y, float z) {
    }

    // ---------------------------------------------------------------- first person
    public static Pose FIRST_PERSON_RIGHT = new Pose(1.13f, 3.2f, 1.13f, 0f, -90f, 25f, 0.68f);
    public static Pose FIRST_PERSON_LEFT = new Pose(-1.13f, 3.2f, 1.13f, 0f, -90f, 25f, 0.68f);

    // ---------------------------------------------------------------- third person
    public static Pose THIRD_PERSON_RIGHT = new Pose(0f, 4f, 0.5f, 0f, -90f, 55f, 0.85f);
    public static Pose THIRD_PERSON_LEFT = new Pose(0f, 4f, 0.5f, 0f, -90f, 55f, 0.85f);

    // ---------------------------------------------------------------- optional swing offsets (first person)
    public static SwingOffset SWING_OFFSET_RIGHT = new SwingOffset(0f, 0f, 0f);
    public static SwingOffset SWING_OFFSET_LEFT = new SwingOffset(0f, 0f, 0f);

    // ---------------------------------------------------------------- behaviour flags (first person)
    /** The off-hand sword plays the same swing as the main hand when attacking. */
    public static boolean OFFHAND_FOLLOWS_MAIN_SWING = true;
    /** The off-hand sword plays the same equip (raise) animation as the main hand. */
    public static boolean OFFHAND_FOLLOWS_MAIN_EQUIP = true;

    // ================================================================ SPRINT (player only)
    // Poses are absolute and use the same units as the poses above. States, timing use and curves live in
    // DualSwordAnimation: IDLE -> SPRINT_ENTER -> SPRINT -> SPRINT_EXIT -> IDLE.

    // ---- timing (client ticks, 1 tick = 50 ms)
    /** IDLE -> SPRINT transition length. */
    public static float SPRINT_ENTER_TICKS = 5f;
    /** SPRINT -> IDLE transition length (a bit longer: it carries the overshoot + settle). */
    public static float SPRINT_EXIT_TICKS = 6f;
    /**
     * Sprint must stay released this long (ticks) before SPRINT_EXIT starts. Vanilla drops the sprint flag for
     * a tick when you hit something or brush a wall; without this grace the swords would flick out of the sprint
     * pose and straight back (visible stutter while sprint-attacking).
     */
    public static float SPRINT_RELEASE_GRACE_TICKS = 2f;
    /**
     * Fraction of each main move (ENTER move / EXIT) spent ramping up from zero speed, so a move never starts
     * with a velocity jump. 0 = off (old behaviour). Kept small so the moves stay as snappy as before.
     */
    public static float SPRINT_MOVE_RAMP = 0.15f;

    // ---- enter feel
    /** Wind-up at the start of ENTER, as a fraction of the idle->sprint distance (backwards). */
    public static float SPRINT_ENTER_ANTICIPATION = 0.10f;
    /** Fraction of the ENTER time the wind-up takes. */
    public static float SPRINT_ENTER_ANTICIPATION_SPAN = 0.30f;
    /** "Back" ease strength of the ENTER main move (0 = none, 1.7 = vanilla-style big overshoot). */
    public static float SPRINT_ENTER_OVERSHOOT = 0.6f;

    // ---- exit feel
    /** "Back" ease strength of the EXIT move: it passes idle slightly, then settles exactly on idle. */
    public static float SPRINT_EXIT_OVERSHOOT = 1.1f;

    // ---- first person (hand space, same as FIRST_PERSON_*)
    /** Right sword: lowered vs idle, blade pitched forward/down, kept inside the screen. */
    public static Pose FIRST_PERSON_RIGHT_SPRINT = new Pose(0.97f, -0.01f, -4.78f, -100f, -90f, 25f, 0.68f);
    /**
     * Left sword "carried on the back". The back is behind the camera, so in first person the sword is shown
     * lying diagonally in the lower-left of the screen (hilt left/low, blade up and inward), smaller than idle.
     */
    public static Pose FIRST_PERSON_LEFT_SPRINT_BACK = new Pose(3.28f, 3.0f, 3.17f, 0f, -30f, -15f, 0.44f);
    /** Run bob (1/16 units / degrees), scaled by run intensity. */
    public static float FIRST_PERSON_RIGHT_BOB_Y = 0.35f;
    public static float FIRST_PERSON_LEFT_BOB_Y = 0.30f;
    public static float FIRST_PERSON_BOB_PITCH_DEG = 1.5f;

    // ---- third person
    /** Right sword in the hand: pitched down-forward, a little lower and further out than idle. */
    public static Pose THIRD_PERSON_RIGHT_SPRINT = new Pose(1.2f, 3.07f, -3.59f, -40f, -90f, 45f, 0.85f);
    /** Right-hand sword secondary motion: lagging pitch sway and footfall bob. */
    public static float THIRD_PERSON_RIGHT_SWAY_DEG = 4.0f;
    public static float THIRD_PERSON_RIGHT_BOB_Y = 0.30f;

    // ---- shared
    /** Phase lag (radians) of secondary motion behind the arm swing: gives follow-through / weight. */
    public static float SPRINT_FOLLOW_LAG = 0.7f;

    public static Pose firstPerson(Arm arm) {
        return arm == Arm.RIGHT ? FIRST_PERSON_RIGHT : FIRST_PERSON_LEFT;
    }

    public static Pose thirdPerson(Arm arm) {
        return arm == Arm.RIGHT ? THIRD_PERSON_RIGHT : THIRD_PERSON_LEFT;
    }

    public static SwingOffset swingOffset(Arm arm) {
        return arm == Arm.RIGHT ? SWING_OFFSET_RIGHT : SWING_OFFSET_LEFT;
    }
}
