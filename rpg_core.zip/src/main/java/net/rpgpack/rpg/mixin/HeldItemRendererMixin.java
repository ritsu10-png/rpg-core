package net.rpgpack.rpg.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.rpgpack.rpg.client.render.DualSwordRenderer;
import net.rpgpack.rpg.client.render.DualSwordTransforms;
import net.rpgpack.rpg.item.DualSwordItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * First person. Vanilla calls renderFirstPersonItem once for the main hand and once for the off hand.
 *  - MAIN hand holding a Dual Sword  -> render that arm's sword instead of the vanilla (X icon) item.
 *  - OFF hand EMPTY while the main hand holds a Dual Sword -> render the second sword there.
 * Every other case falls through to vanilla untouched.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Shadow
    private float equipProgressMainHand;
    @Shadow
    private float prevEquipProgressMainHand;

    @Shadow
    protected abstract void applyEquipOffset(MatrixStack matrices, Arm arm, float equipProgress);

    @Shadow
    protected abstract void applySwingOffset(MatrixStack matrices, Arm arm, float swingProgress);

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
    private void rpg$renderDualSword(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                     float swingProgress, ItemStack item, float equipProgress,
                                     MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                     CallbackInfo ci) {
        DualSwordItem dual = DualSwordRenderer.getMainHandDualSword(player);
        if (dual == null) {
            return;
        }

        boolean isMain = hand == Hand.MAIN_HAND;
        if (isMain) {
            if (!(item.getItem() instanceof DualSwordItem)) {
                return;
            }
        } else if (!item.isEmpty()) {
            return; // something else is in the off hand: vanilla renders it
        }

        Arm arm = isMain ? player.getMainArm() : player.getMainArm().getOpposite();

        float swing = swingProgress;
        float equip = equipProgress;
        if (!isMain) {
            if (DualSwordTransforms.OFFHAND_FOLLOWS_MAIN_SWING) {
                swing = player.getHandSwingProgress(tickDelta);
            }
            if (DualSwordTransforms.OFFHAND_FOLLOWS_MAIN_EQUIP) {
                equip = 1.0f - MathHelper.lerp(tickDelta, this.prevEquipProgressMainHand, this.equipProgressMainHand);
            }
        }

        // same pre-transform chain vanilla uses for a plain held item
        boolean right = arm == Arm.RIGHT;
        float n = -0.4f * MathHelper.sin(MathHelper.sqrt(swing) * (float) Math.PI);
        float o = 0.2f * MathHelper.sin(MathHelper.sqrt(swing) * ((float) Math.PI * 2f));
        float p = -0.2f * MathHelper.sin(swing * (float) Math.PI);
        int q = right ? 1 : -1;

        matrices.push();
        matrices.translate(q * n, o, p);
        this.applyEquipOffset(matrices, arm, equip);
        this.applySwingOffset(matrices, arm, swing);
        DualSwordRenderer.renderFirstPerson(matrices, vertexConsumers, light, dual.getMaterial(), arm, swing, player, tickDelta);
        matrices.pop();

        ci.cancel();
    }
}
