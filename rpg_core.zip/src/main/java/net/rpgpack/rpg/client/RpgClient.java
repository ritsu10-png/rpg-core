package net.rpgpack.rpg.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;
import net.rpgpack.rpg.client.animation.RpgAnimatable;
import net.rpgpack.rpg.client.animation.dualsword.DualSwordAnimations;
import net.rpgpack.rpg.client.render.DualSwordMeshes;

public class RpgClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        DualSwordAnimations.register();

        // One animation tick per client tick for every player in the world (local + remote).
        ClientTickEvents.END_WORLD_TICK.register(world -> {
            for (AbstractClientPlayerEntity player : world.getPlayers()) {
                ((RpgAnimatable) player).rpg$getAnimationState().tick();
            }
        });

        // Hand meshes are generated from the hand textures; rebuild them after every resource reload.
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(
                new SimpleSynchronousResourceReloadListener() {
                    @Override
                    public Identifier getFabricId() {
                        return new Identifier(Rpg.MOD_ID, "dual_sword_meshes");
                    }

                    @Override
                    public void reload(ResourceManager manager) {
                        DualSwordMeshes.clear();
                    }
                });
    }
}
