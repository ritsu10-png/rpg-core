package net.rpgpack.rpg.client.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

/** Base transforms for the custom Dual Sword mesh. PlayerAnimator owns player-arm animation. */
public final class DualSwordTransforms {
    private DualSwordTransforms() {}

    public static final float FP_RIGHT_X = 1.13f;
    public static final float FP_LEFT_X = -1.13f;
    public static final float FP_Y = 3.2f;
    public static final float FP_Z = 1.13f;
    public static final float FP_ROT_Y = -90f;
    public static final float FP_ROT_Z = 25f;
    public static final float FP_SCALE = 0.68f;

    public static final float TP_Y = 4f;
    public static final float TP_Z = 0.5f;
    public static final float TP_ROT_Y = -90f;
    public static final float TP_ROT_Z = 55f;
    public static final float TP_SCALE = 0.85f;

    /** Whether the off-hand first-person sword receives vanilla main-hand swing/equip motion. */
    public static final boolean OFFHAND_FOLLOWS_MAIN_SWING = true;
    public static final boolean OFFHAND_FOLLOWS_MAIN_EQUIP = true;

    public static void applyFirstPerson(MatrixStack matrices, Arm arm) {
        float x = arm == Arm.RIGHT ? FP_RIGHT_X : FP_LEFT_X;
        matrices.translate(x / 16f, FP_Y / 16f, FP_Z / 16f);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(FP_ROT_Y));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(FP_ROT_Z));
        matrices.scale(FP_SCALE, FP_SCALE, FP_SCALE);
    }

    public static void applyThirdPerson(MatrixStack matrices, Arm arm) {
        matrices.translate(0f, TP_Y / 16f, TP_Z / 16f);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(TP_ROT_Y));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(TP_ROT_Z));
        matrices.scale(TP_SCALE, TP_SCALE, TP_SCALE);
    }
}
