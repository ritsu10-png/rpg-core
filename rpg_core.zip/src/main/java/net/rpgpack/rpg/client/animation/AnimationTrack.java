package net.rpgpack.rpg.client.animation;

import java.util.List;

/**
 * A timeline of keyframes (strictly increasing time) that can be sampled at any time.
 * Built once; {@link #evaluate} only reads arrays and writes into the caller's buffer (no allocation).
 * Before the first key / after the last key the pose is held.
 */
public final class AnimationTrack {
    private final float[] times;
    private final Pose[] poses;
    private final Interpolation[] modes;
    private final int count;

    public AnimationTrack(List<Keyframe> keys) {
        if (keys.isEmpty()) {
            throw new IllegalArgumentException("A track needs at least one keyframe");
        }
        count = keys.size();
        times = new float[count];
        poses = new Pose[count];
        modes = new Interpolation[count];
        for (int i = 0; i < count; i++) {
            Keyframe k = keys.get(i);
            if (i > 0 && k.time() <= times[i - 1]) {
                throw new IllegalArgumentException("Keyframe times must be strictly increasing (index " + i + ")");
            }
            times[i] = k.time();
            poses[i] = k.pose();
            modes[i] = k.interpolation();
        }
    }

    /** Writes the pose at normalised time {@code t} into {@code out} (overwrites every channel). */
    public void evaluate(float t, PoseBuffer out) {
        if (t <= times[0] || count == 1) {
            out.set(poses[0]);
            return;
        }
        if (t >= times[count - 1]) {
            out.set(poses[count - 1]);
            return;
        }
        int i = 0;
        while (times[i + 1] <= t) {
            i++;
        }
        float t0 = times[i];
        float dt = times[i + 1] - t0;
        float u = (t - t0) / dt;
        Interpolation mode = modes[i];
        Pose a = poses[i];
        Pose b = poses[i + 1];

        if (mode == Interpolation.CATMULL_ROM) {
            // cubic Hermite with Catmull-Rom tangents (finite difference of the neighbouring keys, any spacing)
            float u2 = u * u;
            float u3 = u2 * u;
            float h00 = 2f * u3 - 3f * u2 + 1f;
            float h10 = u3 - 2f * u2 + u;
            float h01 = -2f * u3 + 3f * u2;
            float h11 = u3 - u2;
            for (int ch = 0; ch < Pose.CHANNELS; ch++) {
                float m0 = tangent(ch, i) * dt;
                float m1 = tangent(ch, i + 1) * dt;
                out.set(ch, h00 * a.channel(ch) + h10 * m0 + h01 * b.channel(ch) + h11 * m1);
            }
            return;
        }

        float w = mode.apply(u);
        for (int ch = 0; ch < Pose.CHANNELS; ch++) {
            float from = a.channel(ch);
            out.set(ch, from + (b.channel(ch) - from) * w);
        }
    }

    /** Speed of a channel at key k. Zero at the two ends of the track (it starts and ends at rest). */
    private float tangent(int ch, int k) {
        if (k <= 0 || k >= count - 1) {
            return 0f;
        }
        return (poses[k + 1].channel(ch) - poses[k - 1].channel(ch)) / (times[k + 1] - times[k - 1]);
    }
}
