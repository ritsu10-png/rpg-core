package net.rpgpack.rpg.mixin;

import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.rpgpack.rpg.client.render.DualSwordAttackAnimation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Third person attack. Runs at the very end of vanilla's setAngles: vanilla has just rebuilt EVERY part pose from
 * scratch for this frame (walk cycle, crouch, item pose, vanilla swing), so the small attack offsets added here
 * sit on top of the normal pose and are simply gone next frame - they can never accumulate.
 * PlayerEntityModel copies body/arms to jacket/sleeves AFTER this returns, and armor / held items read the part
 * transforms later in the same render, so all of them follow automatically.
 */
@Mixin(BipedEntityModel.class)
public abstract class BipedEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("RETURN"))
    private void rpg$dualSwordAttack(LivingEntity entity, float limbAngle, float limbDistance,
                                     float animationProgress, float headYaw, float headPitch, CallbackInfo ci) {
        if (entity instanceof PlayerEntity) {
            DualSwordAttackAnimation.apply((BipedEntityModel<?>) (Object) this, entity, animationProgress);
        }
    }
}
