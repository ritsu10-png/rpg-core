package net.rpgpack.rpg.client.render;

import net.minecraft.util.Arm;

/**
 * SINGLE place that holds every tunable value for the Dual Sword hand rendering.
 *
 * Pose fields:
 *   x/y/z       translation in 1/16 block units (same units as item "display" JSON)
 *   rotX/Y/Z    rotation in degrees (applied X, then Y, then Z - same as vanilla item display transforms)
 *   scale       uniform scale
 *
 * The initial values start from vanilla's "item/handheld" display transforms (mirrored for the left hand),
 * which already put a sword sprite naturally in each hand. Tweak them here - nothing else needs to change.
 *
 * Future animation phases (idle stance, attack, skills, roll) can swap these Pose values at runtime
 * (the fields are non-final on purpose) or add more offsets next to the swing offsets below.
 */
public final class DualSwordTransforms {
    private DualSwordTransforms() {
    }

    public record Pose(float x, float y, float z, float rotX, float rotY, float rotZ, float scale) {
    }

    /** Extra translation (1/16 units) added while swinging, multiplied by sin(swingProgress * PI). */
    public record SwingOffset(float x, float y, float z) {
    }

    // ---------------------------------------------------------------- first person
    public static Pose FIRST_PERSON_RIGHT = new Pose(1.13f, 3.2f, 1.13f, 0f, -90f, 25f, 0.68f);
    public static Pose FIRST_PERSON_LEFT = new Pose(-1.13f, 3.2f, 1.13f, 0f, -90f, 25f, 0.68f);

    // ---------------------------------------------------------------- third person
    public static Pose THIRD_PERSON_RIGHT = new Pose(0f, 4f, 0.5f, 0f, -90f, 55f, 0.85f);
    public static Pose THIRD_PERSON_LEFT = new Pose(0f, 4f, 0.5f, 0f, -90f, 55f, 0.85f);

    // ---------------------------------------------------------------- optional swing offsets (first person)
    public static SwingOffset SWING_OFFSET_RIGHT = new SwingOffset(0f, 0f, 0f);
    public static SwingOffset SWING_OFFSET_LEFT = new SwingOffset(0f, 0f, 0f);

    // ---------------------------------------------------------------- behaviour flags (first person)
    /** The off-hand sword plays the same swing as the main hand when attacking. */
    public static boolean OFFHAND_FOLLOWS_MAIN_SWING = true;
    /** The off-hand sword plays the same equip (raise) animation as the main hand. */
    public static boolean OFFHAND_FOLLOWS_MAIN_EQUIP = true;

    public static Pose firstPerson(Arm arm) {
        return arm == Arm.RIGHT ? FIRST_PERSON_RIGHT : FIRST_PERSON_LEFT;
    }

    public static Pose thirdPerson(Arm arm) {
        return arm == Arm.RIGHT ? THIRD_PERSON_RIGHT : THIRD_PERSON_LEFT;
    }

    public static SwingOffset swingOffset(Arm arm) {
        return arm == Arm.RIGHT ? SWING_OFFSET_RIGHT : SWING_OFFSET_LEFT;
    }
}
