package net.rpgpack.rpg.item;

import net.minecraft.item.Item;

/** A single inventory item that represents a PAIR of swords. No combat behaviour yet. */
public class DualSwordItem extends Item {
    private final DualSwordMaterial material;

    public DualSwordItem(Settings settings, DualSwordMaterial material) {
        super(settings);
        this.material = material;
    }

    public DualSwordMaterial getMaterial() {
        return material;
    }
}
