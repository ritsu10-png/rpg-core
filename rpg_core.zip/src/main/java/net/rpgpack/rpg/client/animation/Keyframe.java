package net.rpgpack.rpg.client.animation;

/**
 * One key on the timeline.
 *
 * @param time          normalised animation time, 0 (start) .. 1 (end)
 * @param pose          the animation pose (delta from the weapon's base pose) at that time
 * @param interpolation how to travel from THIS key to the next one
 */
public record Keyframe(float time, Pose pose, Interpolation interpolation) {
}
