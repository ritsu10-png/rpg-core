package net.rpgpack.rpg;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import net.rpgpack.rpg.item.ModItems;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Rpg implements ModInitializer {
    public static final String MOD_ID = "rpg";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Builds an identifier in the "rpg" namespace. */
    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.register();
        LOGGER.info("RPG Core initialized");
    }
}
