package net.rpgpack.rpg.client.animation;

import net.minecraft.util.Arm;

/**
 * The single source of truth for one client player's custom weapon animation. It lives as a field ON the player
 * entity (see AbstractClientPlayerEntityMixin), so its lifecycle is the entity's: respawn, world change and
 * unloading create/drop it together with the player, and remote players have their own.
 *
 * One stack per arm (the sword in that hand), each: BASE (neutral) + ATTACK layer (higher priority).
 * When the ATTACK layer finishes, the stack falls back to the base pose by itself.
 *
 * Written by an attack trigger (client thread), advanced once per client tick, read by the renderer.
 */
public final class PlayerAnimationState {
    /** BASE is the neutral pose below every layer; ATTACK is above it. */
    public static final int PRIORITY_ATTACK = 100;

    private final AnimationLayer rightAttack = new AnimationLayer(PRIORITY_ATTACK);
    private final AnimationLayer leftAttack = new AnimationLayer(PRIORITY_ATTACK);
    private final AnimationStack rightStack = new AnimationStack(rightAttack);
    private final AnimationStack leftStack = new AnimationStack(leftAttack);

    private Arm lastAttackArm;
    private int lastAttackAge;

    /** Starts {@code animation} on that arm's ATTACK layer. {@code age} = player.age at the moment of the attack. */
    public void playAttack(Arm arm, Animation animation, float speed, float fadeTicks, int age) {
        (arm == Arm.RIGHT ? rightAttack : leftAttack).player().play(animation, speed, fadeTicks);
        lastAttackArm = arm;
        lastAttackAge = age;
    }

    /** Once per client tick. */
    public void tick() {
        rightStack.tick();
        leftStack.tick();
    }

    /** Final animation pose of that arm's sword for this frame; false = base pose (nothing playing). */
    public boolean sample(Arm arm, float tickDelta, PoseBuffer out) {
        return (arm == Arm.RIGHT ? rightStack : leftStack).sample(tickDelta, out);
    }

    /** Arm of the most recent attack, null if none yet. */
    public Arm lastAttackArm() {
        return lastAttackArm;
    }

    public int lastAttackAge() {
        return lastAttackAge;
    }
}
