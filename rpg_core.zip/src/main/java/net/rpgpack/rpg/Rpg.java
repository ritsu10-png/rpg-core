package net.rpgpack.rpg;

import net.fabricmc.api.ModInitializer;
import net.rpgpack.rpg.item.ModItems;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Rpg implements ModInitializer {
    public static final String MOD_ID = "rpg";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.register();
        LOGGER.info("RPG Core initialised (Dual Sword prototype)");
    }
}
