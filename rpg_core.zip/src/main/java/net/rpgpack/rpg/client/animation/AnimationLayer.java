package net.rpgpack.rpg.client.animation;

/**
 * One layer of a stack: a priority (higher wins), a weight (1 = fully replaces what is below) and the
 * {@link AnimationPlayer} that drives it.
 */
public final class AnimationLayer {
    private final int priority;
    private final AnimationPlayer player = new AnimationPlayer();
    private float weight = 1f;

    public AnimationLayer(int priority) {
        this.priority = priority;
    }

    public int priority() {
        return priority;
    }

    public AnimationPlayer player() {
        return player;
    }

    public float weight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = Math.max(0f, Math.min(1f, weight));
    }

    public void tick() {
        player.tick();
    }

    /** False when this layer contributes nothing (not playing, or weight 0); {@code out} is then untouched. */
    public boolean sample(float tickDelta, PoseBuffer out) {
        return weight > 0f && player.sample(tickDelta, out);
    }
}
