package net.rpgpack.rpg.client.animation;

import java.util.ArrayList;
import java.util.List;

/**
 * A named clip: one keyframe track played over {@code lengthTicks} client ticks (1 tick = 50 ms).
 * Keyframe times are normalised (0..1), so changing the length retimes the whole clip without touching a key.
 * Immutable and shareable between all entities.
 */
public final class Animation {
    private final String name;
    private final float lengthTicks;
    private final AnimationTrack track;

    public Animation(String name, float lengthTicks, AnimationTrack track) {
        if (lengthTicks <= 0f) {
            throw new IllegalArgumentException("lengthTicks must be > 0");
        }
        this.name = name;
        this.lengthTicks = lengthTicks;
        this.track = track;
    }

    public static Builder builder(String name, float lengthTicks) {
        return new Builder(name, lengthTicks);
    }

    public String name() {
        return name;
    }

    public float lengthTicks() {
        return lengthTicks;
    }

    /** Pose {@code elapsedTicks} after the start of the clip (clamped to the clip). */
    public void evaluate(float elapsedTicks, PoseBuffer out) {
        float t = elapsedTicks / lengthTicks;
        track.evaluate(t < 0f ? 0f : Math.min(t, 1f), out);
    }

    public static final class Builder {
        private final String name;
        private final float lengthTicks;
        private final List<Keyframe> keys = new ArrayList<>();

        private Builder(String name, float lengthTicks) {
            this.name = name;
            this.lengthTicks = lengthTicks;
        }

        public Builder key(float time, Pose pose, Interpolation toNext) {
            keys.add(new Keyframe(time, pose, toNext));
            return this;
        }

        public Animation build() {
            return new Animation(name, lengthTicks, new AnimationTrack(keys));
        }
    }
}
