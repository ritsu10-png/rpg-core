package net.rpgpack.rpg;

import net.fabricmc.api.ModInitializer;
import net.rpgpack.rpg.item.ModItems;

public class Rpg implements ModInitializer {
    public static final String MOD_ID = "rpg";

    @Override
    public void onInitialize() {
        ModItems.register();
    }
}
