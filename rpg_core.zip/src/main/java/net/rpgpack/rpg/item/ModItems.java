package net.rpgpack.rpg.item;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.rpgpack.rpg.Rpg;

public final class ModItems {
    public static final Item DUAL_SWORD_WOOD = registerDualSword("dual_sword_wood");
    public static final Item DUAL_SWORD_STONE = registerDualSword("dual_sword_stone");
    public static final Item DUAL_SWORD_COPPER = registerDualSword("dual_sword_copper");
    public static final Item DUAL_SWORD_IRON = registerDualSword("dual_sword_iron");
    public static final Item DUAL_SWORD_GOLD = registerDualSword("dual_sword_gold");
    public static final Item DUAL_SWORD_DIAMOND = registerDualSword("dual_sword_diamond");
    public static final Item DUAL_SWORD_NETHERITE = registerDualSword("dual_sword_netherite");

    private ModItems() {
    }

    private static Item registerDualSword(String name) {
        return Registry.register(
                Registries.ITEM,
                new Identifier(Rpg.MOD_ID, name),
                new Item(new Item.Settings().maxCount(1))
        );
    }

    /** Forces class loading so the static item registrations above run. */
    public static void register() {
    }
}
