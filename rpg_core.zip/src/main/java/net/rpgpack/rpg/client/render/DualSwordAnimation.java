package net.rpgpack.rpg.client.render;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.rpgpack.rpg.client.render.DualSwordTransforms.Pose;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Client-side animation STATE + CURVES for the Dual Sword (PLAYER only). All tunable numbers live in
 * {@link DualSwordTransforms}; this class turns "what is the player doing and for how long" into a weight
 * and into poses.
 *
 * States:  IDLE -> SPRINT_ENTER -> SPRINT -> SPRINT_EXIT -> IDLE
 *  - IDLE          no state is stored; the renderer uses the existing idle poses untouched.
 *  - SPRINT_ENTER  swords travel from the idle stance into the sprint stance (short wind-up, snappy move,
 *                  tiny overshoot). Interrupted by a stop, it turns into SPRINT_EXIT from the CURRENT weight.
 *  - SPRINT        held while sprinting, with a subtle run bob / sway.
 *  - SPRINT_EXIT   swords travel back to the idle stance (tiny overshoot past idle, then settle exactly on idle).
 *                  Interrupted by a new sprint, it turns into SPRINT_ENTER from the CURRENT weight.
 *
 * Every transition starts from the weight the animation currently has, so nothing ever snaps.
 * Animation language (meant for later states too): short anticipation -> snappy main move -> small overshoot
 * -> small settle -> secondary motion.
 */
public final class DualSwordAnimation {
    private static final float PI = (float) Math.PI;
    /** Vanilla walk cycle: arm pitch = cos(limbPos * 0.6662 ...). Using the same phase keeps us in sync with the arms. */
    private static final float LIMB_PHASE = 0.6662f;

    public enum State {
        IDLE, SPRINT_ENTER, SPRINT, SPRINT_EXIT
    }

    /** Entity -> its current animation track. Weak so unloaded players vanish. */
    private static final Map<Entity, Track> TRACKS = new WeakHashMap<>();

    private DualSwordAnimation() {
    }

    private static final class Track {
        State state;
        /** Time (ticks + partial tick) the current state started. */
        float start;
        /** Weight the current state started from (0 = idle pose, 1 = full sprint pose). */
        float from;
        /** Last time this track was updated; used to detect "not rendered for a while". */
        float last;
    }

    /**
     * One frame of sprint animation (never exists for IDLE).
     *
     * @param state     SPRINT_ENTER, SPRINT or SPRINT_EXIT
     * @param ticks     time spent in the current state
     * @param blend     idle -> sprint weight: 0 = exact idle pose, 1 = exact sprint pose;
     *                  slightly below 0 / above 1 during anticipation and overshoot
     * @param phase     run-cycle phase in radians, in sync with the vanilla arm swing
     * @param intensity 0..1 how fast the player is moving (scales all secondary motion)
     */
    public record Sprint(State state, float ticks, float blend, float phase, float intensity) {
    }

    // ------------------------------------------------------------------ state machine

    /**
     * Advances this player's state machine to the current render time and returns the frame,
     * or null when the player is in IDLE (nothing to apply).
     * Safe to call several times per frame (first person calls it once per hand).
     */
    public static Sprint sprint(PlayerEntity player, float tickDelta) {
        boolean sprinting = player.isSprinting();
        float now = player.age + tickDelta;

        Track track = TRACKS.get(player);
        // not rendered for a while / time went backwards (world change): forget the old track
        if (track != null && (now < track.last - 1f || now - track.last > 4f)) {
            TRACKS.remove(player);
            track = null;
        }

        if (track == null) {
            if (!sprinting) {
                return null; // IDLE
            }
            track = begin(player, State.SPRINT_ENTER, now, 0f);
        }
        track.last = now;

        float enterTicks = Math.max(0.001f, DualSwordTransforms.SPRINT_ENTER_TICKS);
        float exitTicks = Math.max(0.001f, DualSwordTransforms.SPRINT_EXIT_TICKS);

        switch (track.state) {
            case SPRINT_ENTER -> {
                if (!sprinting) {
                    track = begin(player, State.SPRINT_EXIT, now, weight(track, now));
                } else if (now - track.start >= enterTicks) {
                    track = begin(player, State.SPRINT, now, 1f);
                }
            }
            case SPRINT -> {
                if (!sprinting) {
                    track = begin(player, State.SPRINT_EXIT, now, 1f);
                }
            }
            case SPRINT_EXIT -> {
                if (sprinting) {
                    track = begin(player, State.SPRINT_ENTER, now, weight(track, now));
                } else if (now - track.start >= exitTicks) {
                    TRACKS.remove(player); // back to IDLE: the renderer now uses the existing idle pose
                    return null;
                }
            }
            default -> {
                TRACKS.remove(player);
                return null;
            }
        }
        track.last = now;

        float phase = player.limbAnimator.getPos(tickDelta) * LIMB_PHASE;
        float intensity = MathHelper.clamp(player.limbAnimator.getSpeed(tickDelta), 0f, 1f);
        return new Sprint(track.state, Math.max(0f, now - track.start), weight(track, now), phase, intensity);
    }

    private static Track begin(PlayerEntity player, State state, float now, float from) {
        Track t = new Track();
        t.state = state;
        t.start = now;
        t.from = from;
        t.last = now;
        TRACKS.put(player, t);
        return t;
    }

    // ------------------------------------------------------------------ curves

    /** Idle -> sprint weight of a track at time {@code now}. */
    private static float weight(Track t, float now) {
        float elapsed = Math.max(0f, now - t.start);
        switch (t.state) {
            case SPRINT_ENTER: {
                float u = MathHelper.clamp(elapsed / Math.max(0.001f, DualSwordTransforms.SPRINT_ENTER_TICKS), 0f, 1f);
                float span = MathHelper.clamp(DualSwordTransforms.SPRINT_ENTER_ANTICIPATION_SPAN, 0.05f, 0.9f);
                // tiny wind-up away from the sprint pose ...
                float dip = t.from - DualSwordTransforms.SPRINT_ENTER_ANTICIPATION * (1f - t.from);
                if (u < span) {
                    return t.from + (dip - t.from) * smooth(u / span);
                }
                // ... then the snappy main move with a small overshoot, landing exactly on 1
                float m = (u - span) / (1f - span);
                return dip + (1f - dip) * easeOutBack(m, DualSwordTransforms.SPRINT_ENTER_OVERSHOOT);
            }
            case SPRINT:
                return 1f;
            case SPRINT_EXIT: {
                float u = MathHelper.clamp(elapsed / Math.max(0.001f, DualSwordTransforms.SPRINT_EXIT_TICKS), 0f, 1f);
                // passes idle slightly (negative weight), then settles exactly on 0 = idle
                return t.from * (1f - easeOutBack(u, DualSwordTransforms.SPRINT_EXIT_OVERSHOOT));
            }
            default:
                return 0f;
        }
    }

    private static float smooth(float u) {
        u = MathHelper.clamp(u, 0f, 1f);
        return u * u * (3f - 2f * u);
    }

    /** Fast start, small overshoot past 1, settles on exactly 1 at u = 1. */
    static float easeOutBack(float u, float s) {
        u = MathHelper.clamp(u, 0f, 1f);
        float x = u - 1f;
        return 1f + (s + 1f) * x * x * x + s * x * x;
    }

    // ------------------------------------------------------------------ poses

    /** First person: idle pose blended toward the sprint pose, plus a small run bob. */
    public static Pose firstPersonPose(Arm arm, Sprint s) {
        Pose idle = DualSwordTransforms.firstPerson(arm);
        Pose target = arm == Arm.RIGHT
                ? DualSwordTransforms.FIRST_PERSON_RIGHT_SPRINT
                : DualSwordTransforms.FIRST_PERSON_LEFT_SPRINT_BACK;
        Pose p = Pose.lerp(idle, target, s.blend());

        float k = s.intensity() * MathHelper.clamp(s.blend(), 0f, 1f);
        float bobAmp = arm == Arm.RIGHT
                ? DualSwordTransforms.FIRST_PERSON_RIGHT_BOB_Y
                : DualSwordTransforms.FIRST_PERSON_LEFT_BOB_Y;
        float bobY = MathHelper.cos(2f * s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG) * bobAmp * k;
        float pitch = MathHelper.cos(s.phase() + PI - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.FIRST_PERSON_BOB_PITCH_DEG * k;
        return p.offset(0f, bobY, 0f, pitch, 0f, 0f);
    }

    /** Third person, sword that stays in the hand (right): blended toward the low pose + lagging sway. */
    public static Pose thirdPersonHandPose(Arm arm, Sprint s) {
        Pose idle = DualSwordTransforms.thirdPerson(arm);
        Pose p = Pose.lerp(idle, DualSwordTransforms.THIRD_PERSON_RIGHT_SPRINT, s.blend());

        float k = s.intensity() * MathHelper.clamp(s.blend(), 0f, 1f);
        // the arm already swings the sword; this lags slightly behind it (follow-through)
        float sway = MathHelper.cos(s.phase() + PI - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.THIRD_PERSON_RIGHT_SWAY_DEG * k;
        float bobY = MathHelper.cos(2f * s.phase()) * DualSwordTransforms.THIRD_PERSON_RIGHT_BOB_Y * k;
        return p.offset(0f, bobY, 0f, sway, 0f, 0f);
    }

    /** Third person, left sword on the back (body-part space) + subtle follow-through. */
    public static Pose backPose(Sprint s) {
        Pose p = DualSwordTransforms.BACK_SWORD;

        float k = s.intensity() * MathHelper.clamp(s.blend(), 0f, 1f);
        // the torso bounces at footfall rate; the sword follows a touch later and sways across the back
        float bobY = MathHelper.cos(2f * s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.BACK_BOB_Y * k;
        float swayX = MathHelper.sin(s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.BACK_SWAY_X * k;
        float swayRot = MathHelper.sin(s.phase() - DualSwordTransforms.SPRINT_FOLLOW_LAG)
                * DualSwordTransforms.BACK_SWAY_DEG * k;
        return p.offset(swayX, bobY, 0f, 0f, 0f, swayRot);
    }

    // ------------------------------------------------------------------ hand <-> back travel (third person, left sword)

    /**
     * Blends the left sword between its hand transform and its back transform. Both inputs are full
     * "sword centre" matrices in the same root space as {@code base} (the matrix at the start of the feature
     * renderer). The blend is done relative to {@code base}, i.e. in model space: translation and scale are
     * interpolated linearly, rotation with a slerp, so {@code w} outside 0..1 gives anticipation/overshoot.
     * A small arc away from the body keeps the sword out of the torso while it travels.
     * w = 0 gives exactly {@code hand}, w = 1 exactly {@code back}.
     */
    public static Matrix4f blendHandToBack(Matrix4f base, Matrix4f hand, Matrix4f back, float w) {
        Matrix4f inv = new Matrix4f(base).invert();
        Matrix4f a = new Matrix4f(inv).mul(hand);
        Matrix4f b = new Matrix4f(inv).mul(back);

        Quaternionf qa = a.getUnnormalizedRotation(new Quaternionf());
        Quaternionf qb = b.getUnnormalizedRotation(new Quaternionf());
        Quaternionf q = new Quaternionf(qa).slerp(qb, w);

        float sa = uniformScale(a);
        float sb = uniformScale(b);
        float sc = Math.max(0.05f, sa + (sb - sa) * w);

        float tx = a.m30() + (b.m30() - a.m30()) * w;
        float ty = a.m31() + (b.m31() - a.m31()) * w;
        float tz = a.m32() + (b.m32() - a.m32()) * w;
        // model space: +z is away from the back of the body
        tz += DualSwordTransforms.BACK_TRANSITION_ARC / 16f * MathHelper.sin(PI * MathHelper.clamp(w, 0f, 1f));

        Matrix4f rel = new Matrix4f().translation(tx, ty, tz).rotate(q).scale(sc);
        return new Matrix4f(base).mul(rel);
    }

    private static float uniformScale(Matrix4f m) {
        return (float) Math.sqrt(m.m00() * m.m00() + m.m01() * m.m01() + m.m02() * m.m02());
    }
}
